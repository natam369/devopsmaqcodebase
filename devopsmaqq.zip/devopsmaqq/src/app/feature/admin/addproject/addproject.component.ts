import { Component, OnInit } from '@angular/core';
import { DevopsmaqService } from 'src/app/shared/services/devopsmaq.service';
import { Project } from 'src/app/Project';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {
  FormGroup,
  FormControl, FormBuilder, Validators
} from '@angular/forms';
@Component({
  selector: 'app-addproject',
  templateUrl: './addproject.component.html',
  styleUrls: ['./addproject.component.css']
})
export class AddprojectComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<AddprojectComponent>,private maqservice: DevopsmaqService, private formBuilder: FormBuilder) { }
  project: Project;
  AddProjectForm: FormGroup;
  storedData: any;
  getData: any;
  ngOnInit() {
    this.AddProjectForm = new FormGroup(
      {
        id: new FormControl(''),
        projectName: new FormControl('')
      }
    );
    this.maqservice.getUsersList().subscribe(data => {
      this.storedData = data;
      console.log(this.storedData);
    });
  }
  onSubmit() {
    this.project = new Project(this.AddProjectForm.get('projectName').value);
    console.log(this.project.projectName);
    this.maqservice.saveProject(this.AddProjectForm.get('id').value, this.project).subscribe(data => {
      this.getData = data;
      console.log(this.getData);
    });
  }
  closeDialog() {
    this.dialogRef.close();
  }
}
