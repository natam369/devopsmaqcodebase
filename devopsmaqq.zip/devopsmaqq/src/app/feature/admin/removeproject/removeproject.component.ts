import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {
  FormGroup,
  FormControl, FormBuilder, Validators
} from '@angular/forms';
import { DevopsmaqService } from 'src/app/shared/services/devopsmaq.service';
@Component({
  selector: 'app-removeproject',
  templateUrl: './removeproject.component.html',
  styleUrls: ['./removeproject.component.css']
})
export class RemoveprojectComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<RemoveprojectComponent>, private maqservice: DevopsmaqService, private formBuilder: FormBuilder) { }
  ProjectDeleteForm: FormGroup;
  storedData: any;
  getData: any;
  errorMessage = '';
  isDeleteFailed = false;
  isDeleted = false;
  ngOnInit() {
    this.ProjectDeleteForm = new FormGroup(
      {
        projectId: new FormControl('')
      }
    );

    let resp = this.maqservice.getProjectsList();
    resp.subscribe((data) => this.storedData = data);
    console.log(this.storedData);
  }
  onSubmit() {
    if (confirm("Do you want to delete")) {
      this.maqservice.deleteProject(this.ProjectDeleteForm.get('projectId').value).subscribe(data => 
        {
        this.getData = data;
        this.isDeleteFailed = false;
        this.isDeleted = true;
        if (this.isDeleted) {
          alert("project deleted successfully");
          this.dialogRef.close();
        }

      },
      error => {
        console.log(error);
        this.errorMessage = error.error.message;
        console.log(this.errorMessage);
        this.isDeleteFailed = true;
        if (this.isDeleteFailed) {
          alert("project deletion failed");
        }
      });
      
    }
    
  }
  closeDialog() {
    this.dialogRef.close();
  }
}
