import { Component, OnInit } from '@angular/core';
import { DevopsmaqService } from 'src/app/shared/services/devopsmaq.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {
  FormGroup,
  FormControl, FormBuilder, Validators
} from '@angular/forms';
@Component({
  selector: 'app-assignarchitect',
  templateUrl: './assignarchitect.component.html',
  styleUrls: ['./assignarchitect.component.css']
})
export class AssignarchitectComponent implements OnInit {

  storedData: any;
  getData: any;
  storedData1: any;
  AssignArchitectForm: FormGroup;
  constructor(public dialogRef: MatDialogRef<AssignarchitectComponent>, private maqservice: DevopsmaqService, private formBuilder: FormBuilder) { }


  ngOnInit() {
    this.AssignArchitectForm = new FormGroup(
      {
        projectId: new FormControl(''),
        userId: new FormControl('')
      }
    );
    let resp = this.maqservice.getProjectsList();
    resp.subscribe((data) => this.storedData = data.body);


    let resp1 = this.maqservice.getArchitectList();
    resp1.subscribe((data) => this.storedData1 = data.body);

  }
  onSubmit() {
    console.log("ProjectID::::" + this.AssignArchitectForm.get('projectId').value);
    console.log("USERID::::" + this.AssignArchitectForm.get('userId').value);
    this.maqservice.AssignArchitect(this.AssignArchitectForm.get('projectId').value, this.AssignArchitectForm.get('userId').value).subscribe(data => {
      this.getData = data;
    });

  }
  closeDialog() {
    this.dialogRef.close();
  }
}
