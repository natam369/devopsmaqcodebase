import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignarchitectComponent } from './assignarchitect.component';

describe('AssignarchitectComponent', () => {
  let component: AssignarchitectComponent;
  let fixture: ComponentFixture<AssignarchitectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignarchitectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignarchitectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
