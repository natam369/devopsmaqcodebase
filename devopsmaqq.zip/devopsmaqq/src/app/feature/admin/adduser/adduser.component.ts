import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../shared/auth/auth.service';
import { SignUpInfo } from '../../../shared/auth/signup-info';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
declare var jQuery: any;
@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
  form: any = {};
  signupInfo: SignUpInfo;
  isSignedUp = false;
  isSignUpFailed = false;
  errorMessage = '';
  auths: string[] = ['admin', 'archi','viewer','client'];
  roles: string[] = [];
  constructor(private authService: AuthService,public dialogRef: MatDialogRef<AdduserComponent>) { }

  ngOnInit(): void {
  }
  onSubmit() {
   console.log(this.form.role);
    this.roles.push(this.form.role);
    console.log(this.form);
    this.signupInfo = new SignUpInfo(

      this.form.username,

      this.form.password, this.roles);
      console.log("hai");
    console.log(this.form.role);
    this.authService.signUp(this.signupInfo).subscribe(
      data => {
        console.log(data);
        this.isSignedUp = true;
        this.isSignUpFailed = false;
        alert("user added successfull");
        this.dialogRef.close();
      },
      error => {
        console.log(error);
        this.errorMessage = error.error.message;
        this.isSignUpFailed = true;
        (function ($) {
          $(document).ready(function () {
            // $("#alreadyadded").fadeIn("fast");
            $('#alreadyadded').fadeIn('slow');
            $('#username').focus(function () {
              $('#alreadyadded').fadeOut('fast');
            })
         });
        })(jQuery);
      }
    );
  }
  closeDialog() {
    this.dialogRef.close();
  }
}
