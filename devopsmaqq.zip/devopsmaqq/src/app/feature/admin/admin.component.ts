import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AdduserComponent } from '../admin/adduser/adduser.component';
import { RemoveprojectComponent } from './removeproject/removeproject.component';
import { RemoveuserComponent } from './removeuser/removeuser.component';
import { AddprojectComponent } from './addproject/addproject.component';
import { AssignarchitectComponent} from './assignarchitect/assignarchitect.component';
import { AddprojectandassignComponent } from './addprojectandassign/addprojectandassign.component';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(public dialog: MatDialog,) { }

  ngOnInit(): void {
  }
  openAddUser()
  {
    const dialogRef = this.dialog.open(AdduserComponent, {
      width: '300px',
      data: {}
    });
  }
  openDelProject()
  {
    const dialogRef = this.dialog.open(RemoveprojectComponent, {
      width: '300px',
      data: {}
    });
  }
  openDelUser()
  {
    const dialogRef = this.dialog.open(RemoveuserComponent,{
      width: '300px',
      data: {}
    });
  }
  openAddProject()
  {
    const dialogRef = this.dialog.open(AddprojectComponent, {
      width: '300px',
      data: {}
    });
  }
  openAssignArchitect()
  {
    const dialogRef = this.dialog.open(AssignarchitectComponent, {
      width: '300px',
      data: {}
    });
  }
  openAddProjectandAssign()
  {
    const dialogRef = this.dialog.open(AddprojectandassignComponent, {
      width: '300px',
      data: {}
    });
  }
}
