import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {
  FormGroup,
  FormControl, FormBuilder, Validators
} from '@angular/forms';
import { DevopsmaqService } from 'src/app/shared/services/devopsmaq.service';

@Component({
  selector: 'app-removeuser',
  templateUrl: './removeuser.component.html',
  styleUrls: ['./removeuser.component.css']
})
export class RemoveuserComponent implements OnInit {
  users: any;
  //id:number;
  myForm: FormGroup;
  errorMessage = '';
  isDeleteFailed = false;
  isDeleted = false;
  constructor(public dialogRef: MatDialogRef<RemoveuserComponent>, private maqservice: DevopsmaqService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.myForm = this.formBuilder.group({
      username: ''
    });
    let resp = this.maqservice.getallUsersList();
    resp.subscribe((data) => {
      this.users = data;
      console.log(this.users)
    });
  }
  delteUser(id) {

    console.log("entered on delete");
    console.log("selected to delete id==" + id);
    console.log(id);
    if (confirm("Do you want to delete")) {
      let resp = this.maqservice.deleteUser(id);
      resp.subscribe((data) => {
        this.users = data,
          this.isDeleteFailed = false;
        this.isDeleted = true;
        if (this.isDeleted) {
          alert("user deleted successfully");
        }

      },
        error => {
          console.log(error);
          this.errorMessage = error.error.message;
          console.log(this.errorMessage);
          this.isDeleteFailed = true;
          if (this.isDeleteFailed) {
            alert("user deletion failed");
          }
        }
      );
    }
  }
  closeDialog() {
    this.dialogRef.close();
  }
}
