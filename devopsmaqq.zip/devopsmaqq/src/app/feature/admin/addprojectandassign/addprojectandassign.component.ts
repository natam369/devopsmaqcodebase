import { Component, OnInit, Input } from '@angular/core';
import { DevopsmaqService } from 'src/app/shared/services/devopsmaq.service';
import { Project } from 'src/app/Project';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {
  FormGroup,
  FormControl, FormBuilder, Validators
} from '@angular/forms';
import { Router } from '@angular/router';
import { $ } from 'protractor';
import { start } from 'repl';
import { endianness } from 'os';
declare var jQuery: any;
@Component({
  selector: 'app-addprojectandassign',
  templateUrl: './addprojectandassign.component.html',
  styleUrls: ['./addprojectandassign.component.css']
})
export class AddprojectandassignComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<AddprojectandassignComponent>, private maqservice: DevopsmaqService, private formBuilder: FormBuilder) { }
  project: Project;
  AddProjectForm: FormGroup;
  storedData: any;
  isAdded = false;
  storedData1: any;
  storedData2: any;
  userId: number;
  architectId: number;
  getData: any;
  message: string;
  messagee: string;
  ngOnInit() {
    this.AddProjectForm = new FormGroup(
      {
        userId: new FormControl(''),
        projectId: new FormControl(''),
        projectName: new FormControl(''),
        architectId: new FormControl('')
      }
    );
    this.maqservice.getUsersList().subscribe(data => {
      this.storedData = data.body;
      console.log(this.storedData);

    });
    this.maqservice.getProjectsList().subscribe(data => {
      this.storedData1 = data.body;
      console.log(this.storedData1);

      (function ($) {
        $(document).ready(function () {

          // $("#displayField").prop('disabled', true);
          $("#displayField").hide();
          $(".errmsg").hide();
          $("#newproject").hide();
          // alert("hello");
          $("#projects").change(function () {
            // alert($("#projects").val());
            if ($("#projects").val() == "others") {
              // alert($("#projects").val());
              // alert("hai")
              //console.log(this.AddProjectForm.get('projectId').value);
              //$("#displayField").prop('disabled', false);
              $("#displayField").show();
              $("#newproject").show();
              // start
              $("#displayField").blur(

                function () {
                  let count = 0;
                  let flag=false;
                  for (let i = 0; i < data.body.length; i++) {
                    count++;
                    if ($("#displayField").val() === data.body[i].projectName) {
                      // $(".errmsg").show();
                      // $(".addbtn").hide();
                      flag=true;
                      break;

                    }
                  }
                  console.log(count);
                  if(flag)
                  {
                    $(".errmsg").show();
                    $(".addbtn").prop("disabled",true);
                  }
                  else
                  {
                    $(".errmsg").hide();
                    $(".addbtn").prop("disabled",false);
                  }
                }
              );
              // end
              $("#displayField").attr("name", "name");
              $("#projects").attr("name", "");
            }
            else {
              // alert($("#projects").val());
              //$("#displayField").prop('disabled', true);
              $("#displayField").hide();
              $("#newproject").hide();
              $("#projects").attr("name", "name");
              $("#displayField").attr("name", "");
            }
          });

        });
      })(jQuery);

    });
    this.maqservice.getArchitectList().subscribe(data => {
      this.storedData2 = data.body;
      console.log(this.storedData2);

    });
    // let resp1 = this.maqservice.getArchitectList();
    // resp1.subscribe((data) => this.storedData1 = data.body);


  }
  onSubmit() {
    if (this.AddProjectForm.get('projectId').value === "others") {
      // console.log("hello");

      this.project = new Project(this.AddProjectForm.get('projectName').value);
      // console.log(this.project);
    //   for (let p of this.storedData1) {
    //     console.log(p);
    //     if (this.project.projectName.trim() === p.projectName.trim()) {
    //       this.isAdded = true;
    //       this.messagee = "project already exists, assign an architect";

    //     }
    //   }

    }

    else {
      this.project = new Project(this.AddProjectForm.get('projectId').value);

    }
    console.log(this.project);
    this.userId = this.AddProjectForm.get('userId').value
    console.log(this.AddProjectForm.get('userId').value);
    this.architectId = this.AddProjectForm.get('architectId').value
    console.log(this.AddProjectForm.get('architectId').value);
    this.maqservice.addProject(this.project, this.userId, this.architectId).subscribe(data => {
      this.getData = data;
      this.isAdded = true;
      this.message = data.message;
      console.log(this.getData);
      (function ($) {
        $(document).ready(function () {
          // $("#alreadyadded").fadeIn("fast");
          $('#successful').fadeIn('slow');
          $('#projects').focus(function () {
            $('#successful').fadeOut('fast');
          })
       });
      })(jQuery);
      if(this.message!=null)
      {
        alert("project added successfully!");
        this.dialogRef.close();
      }
    });
  }
  closeDialog() {
    this.dialogRef.close();
  }

}
