import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddprojectandassignComponent } from './addprojectandassign.component';

describe('AddprojectandassignComponent', () => {
  let component: AddprojectandassignComponent;
  let fixture: ComponentFixture<AddprojectandassignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddprojectandassignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddprojectandassignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
