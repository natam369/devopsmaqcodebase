import { Component, OnInit } from '@angular/core';
import { DevopsmaqService } from 'src/app/shared/services/devopsmaq.service';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import {
  FormGroup,
  FormControl, FormBuilder, Validators, FormArray
} from '@angular/forms';
import { TokenStorageService } from '../../shared/auth/token-storage.service';
declare var jQuery: any;

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']
})

export class QuestionsComponent implements OnInit {
  categoryId: 0;
  len: number;
  str: any;

  public FeedBackForm: FormGroup;
  feedback: any[] = [];
  solutions: any[] = [];
  getData: any;
  questions = [];
  username: string;
  abc: number;
  button: string;
  areaList: any;
  alength: number;
  questionList: any;
  categoryList: any[] = [];
  qlength: any;
  ExistingFeedback: any;
  feedbackLength: number;
  qstnFeedback: any;
  questionForpatch: any;
  catBasedquestionList: any[] = [];
  setValues: any[] = [];
  catBasedFeedback: any[] = [];
  values: any = ["Always", "Often", "Sometimes", "Seldom", "Never", "Not Applicable"];
  mySubscription: any;
  constructor(private token: TokenStorageService, private maqservice: DevopsmaqService, private route: ActivatedRoute, private router: Router, private formBuilder: FormBuilder) {
    this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    };
    this.mySubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        // Trick the Router into believing it's last link wasn't previously loaded
        this.router.navigated = false;
      }
    });
  }
  ngOnInit() {
    console.log(window.sessionStorage.getItem('projectId'));
    // JSON.parse(window.sessionStorage.getItem('projectId'));
    this.abc = JSON.parse(window.sessionStorage.getItem('projectId'));
    console.log(this.abc);

    this.username = this.token.getUsername();
    this.initialiseFormGroup();
    (function ($) {
      $(document).ready(function () {
        console.log("jqueryy")

        $("#generateBtn").hide()

      });
    })(jQuery);
    console.log("inside ng on it of questions")
    // this.categoryId = this.route.snapshot.params['categoryId'];
    // console.log(this.categoryId);
    this.route.params.subscribe((params) => {
      this.categoryId = params['categoryId'];
      let resp = this.maqservice.getQuestionsList(this.categoryId);
      resp.subscribe((data:any) => {
        this.str = JSON.stringify(data);
        this.questions = data.body;
        this.len = this.questions.length;
        this.deleteSolutions();
        for (let i = 0; i < this.questions.length; i++) {
          this.addSolutionDetails();
          this.solutionDetailsArr.at(i).patchValue({
            question: this.questions[i].question,
            questionId: this.questions[i].questionId
          })
        }
      });
    });

    this.maqservice.getAreasList().subscribe((data:any) => {
      this.areaList = data.body;
      console.log("areas list");
      console.log(this.areaList);
      console.log(this.areaList.length);
      for (let c of this.areaList[this.areaList.length - 1].categories) {
        this.categoryList.push(c);
      }
      console.log("categories in last area");
      console.log(this.categoryList);
      let c = this.categoryList.length;
      console.log(c);
      console.log(this.categoryList[3].categoryId);
      if (this.categoryId == this.categoryList[this.categoryList.length - 1].categoryId) {
        console.log("in cat if ")
        this.button = "submit";
        console.log("button value", this.button);
      }
      else {
        this.button = "save";
        console.log("button value", this.button);
      }
    });
    this.maqservice.getAllQuestions().subscribe((data:any) => {
      this.questionList = data.body;
      console.log(this.questionList);
      for (let c of this.categoryList) {
        //if(q.category.categoryId==)
        let i = 0;
        for (let q of this.questionList) {
          if (q.category.categoryId == this.categoryList[this.categoryList.length - 1].categoryId) {
            i++;
          }
        }
        this.qlength = i;
        console.log("question length", this.qlength)

      }
      console.log("this is qstn length");
      console.log(this.qlength);
    });
    this.maqservice.getAllQuestionsForPatchValues(this.username, this.abc).subscribe((data:any) => {
      this.questionForpatch = data;

      console.log("this is in qstn part")
      console.log(this.questionForpatch)
      for (let q of this.questionForpatch) {

        if (q.category.categoryId == this.categoryId) {
          this.catBasedFeedback.push(q);
        }
      }
      //console.log("catbased")
      // console.log(this.catBasedquestionList);
      console.log("setting values in setValues", this.catBasedFeedback)
      console.log("feed", this.catBasedFeedback[0].question.questionId)
      console.log("res", this.catBasedFeedback[0].response)
      if (this.catBasedFeedback.length != 0) {
        this.setPatchValue(this.catBasedFeedback)
      }
    });

    this.maqservice.getExistingFeedback(this.username, this.abc).subscribe((data:any) => {
      this.ExistingFeedback = data.body;
      this.feedbackLength = 0;
      let length = 0;

      console.log(this.ExistingFeedback);
    });
  }

  ngOnDestroy() {
    if (this.mySubscription) {
      this.mySubscription.unsubscribe();
    }
  }
  setPatchValue(catBasedFeedback: any) {
    this.deleteSolutions();
    for (const [index, item] of catBasedFeedback.entries()) {

      this.addSolutionDetails();
      const ExistingFeedbackFormGroup = this.solutionDetailsArr.at(index) as FormGroup;

      ExistingFeedbackFormGroup.patchValue({
        questionId: item.question.questionId,
        question: item.question.question,
        option: item.response,
        remarks: item.remarks,
      });
    }
    if (this.ExistingFeedback.length == this.questionList.length) {
      (function ($) {
        $(document).ready(function () {
          console.log("jqueryy")

          $("#savebtn").hide()
           $("#generateBtn").show()

        });
      })(jQuery);

    }

  }

  initialiseFormGroup() {
    const inputValue = {
      value: '',
      disabled: false,
    };
    this.FeedBackForm = this.formBuilder.group({
      solution: this.formBuilder.array([])
    });
  }
  get solutionDetails() {
    const SolutionFormGroup = this.formBuilder.group({
      question: ['', Validators.required],
      questionId: ['', Validators.required],
      //option: ['', Validators.required],
      option: ['', Validators.required],
      remarks: [''],
    }) as FormGroup;
    return SolutionFormGroup;
  }

  get solutionDetailsArr() {
    return this.FeedBackForm.get('solution') as FormArray;
  }
  addSolutionDetails() {
    this.solutionDetailsArr.push(this.solutionDetails);
  }
  deleteSolutions() {
    this.solutionDetailsArr.clear();
  }
  calculate() {
    this.maqservice.calculateScores(this.abc).subscribe((data:any) => {
      this.qstnFeedback = data;

    });
    this.router.navigate(["client/board"]);
  }
  onSubmit() {
    console.log(window.sessionStorage.getItem('projectId'));
    // JSON.parse(window.sessionStorage.getItem('projectId'));
    this.abc = JSON.parse(window.sessionStorage.getItem('projectId'));
    console.log(this.abc);
    this.feedback = this.FeedBackForm.value.solutions;
    this.username = this.token.getUsername();
    console.log("solutionn set...................")
    // console.log(this.feedback.values)
    console.log(this.FeedBackForm.value);
    console.log("solution")
    console.log(this.solutionDetailsArr.value)


    // this.userForm.get('name').value
    console.log("submitted");
    this.maqservice.getExistingQuestionFeedback(this.username, this.abc).subscribe((data:any) => {
      this.qstnFeedback = data;
      console.log("check 1 2 3");
      console.log(this.qstnFeedback.body.length);
    });

    if (this.button === "save") {
      this.maqservice.saveFeedBack(this.FeedBackForm.value, this.username, this.abc).subscribe((data:any) => {
        this.getData = data;
        console.log(this.getData);
        alert("data submitted successfully!!")
        window.location.reload();

      });

    }
    else {
      let flag = false;
      console.log(this.ExistingFeedback.length);
      console.log(this.questionList.length);
      console.log(this.qlength);
      if (this.ExistingFeedback.length === this.questionList.length - this.qlength) {
        console.log("after solution array")
        flag = false;
        for (let s of this.solutionDetailsArr.value) {
          console.log(s.option)
          if (s.option === 6) {
            flag = true;
            break;
          }
        }
        if (flag == false) {
          if (confirm("Do you want to submit your assessment")) {
            this.maqservice.saveFeedBack(this.FeedBackForm.value, this.username, this.abc).subscribe((data:any) => {
              this.getData = data;
              console.log(this.getData);
              alert("data submitted successfully!!")

              window.location.reload();
             // this.router.navigate(["client/board"]);
            });
            (function ($) {
              $(document).ready(function () {
                console.log("jqueryy")

                $("#savebtn").hide()
                $("#generateBtn").show()

              });
            })(jQuery);
          }


        }
        else {
          alert("please select some value for all")
        }

      }
      else if (this.ExistingFeedback.body.length === this.questionList.length) {
        console.log("in else if.................");
        (function ($) {
          $(document).ready(function () {
            console.log("jqueryy")
            alert("jquery")
            $("#savebtn").hide()
            $("#generateBtn").show()

          });
        })(jQuery);
        // window.location.reload();
      }
      else {
        alert("please fill remaining categories");
      }
    }
  }
}



