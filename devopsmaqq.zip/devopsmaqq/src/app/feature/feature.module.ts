import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FeatureRoutingModule } from './feature-routing.module';
import { LoginComponent } from './login/login.component';
import { UserAreasComponent } from './user-areas/user-areas.component';
import { AreasComponent } from './areas/areas.component';
import { CategoriesComponent } from './categories/categories.component';
import { QuestionsComponent } from './questions/questions.component';
import { AdduserComponent } from './admin/adduser/adduser.component';
import { RemoveuserComponent } from './admin/removeuser/removeuser.component';
import { AddprojectComponent } from './admin/addproject/addproject.component';
import { RemoveprojectComponent } from './admin/removeproject/removeproject.component';
import { LogoutComponent } from './logout/logout.component';
import { HomeComponent } from './home/home.component';
import { ErrorComponent } from './error/error.component';
import { AdminComponent } from './admin/admin.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../material/material.module';

import { HttpClientModule } from '@angular/common/http';
import { AccessdeniedComponent } from './accessdenied/accessdenied.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ScorecardComponent } from './scorecard/scorecard.component';
import { AssignarchitectComponent } from './admin/assignarchitect/assignarchitect.component';
import { AddprojectandassignComponent } from './admin/addprojectandassign/addprojectandassign.component';
import { ClientComponent } from './client/client.component';
import { ViewerComponent } from './viewer/viewer.component';
import { ClientboardComponent } from './clientboard/clientboard.component';
import { CoreModule } from '../core/core.module';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';

@NgModule({
  declarations: [
    LoginComponent,
    UserAreasComponent,
    AreasComponent,
    CategoriesComponent,
    QuestionsComponent,
    AdduserComponent,
    RemoveuserComponent,
    AddprojectComponent,
    RemoveprojectComponent,
    LogoutComponent,
    HomeComponent,
    ErrorComponent,
    AdminComponent,
    AccessdeniedComponent,
    DashboardComponent,
    ScorecardComponent,
    AssignarchitectComponent,
    AddprojectandassignComponent,
    ClientComponent,
    ViewerComponent,
    ClientboardComponent,
    ResetpasswordComponent],
  imports: [
    CommonModule,
    FeatureRoutingModule,
    FormsModule,
    CoreModule,
    ReactiveFormsModule,
    MaterialModule,
    HttpClientModule,
    ReactiveFormsModule,
  ],
})
export class FeatureModule { }
