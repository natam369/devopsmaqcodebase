import { Component, OnInit } from '@angular/core';
import { DevopsmaqService } from 'src/app/shared/services/devopsmaq.service';
@Component({
  selector: 'app-areas',
  templateUrl: './areas.component.html',
  styleUrls: ['./areas.component.css']
})
export class AreasComponent implements OnInit {
  storedData: any;
  Feedback: any;
  username: string;
  projectId: number;
  questionList: any;
  qFeedback: any;
  // areaId = 301;
  //areaId: any;
  areas: any;
  //count:number;
  qcount:number;
  existingQCount:number;
  constructor(private maqservice: DevopsmaqService) { }
  ngOnInit() {

    this.projectId = JSON.parse(window.sessionStorage.getItem('projectId'));

    console.log(this.projectId);
    this.username = window.sessionStorage.getItem('AuthUsername')

    this.maqservice.getAreasList().subscribe(data => {
      this.storedData = data.body;
      console.log(this.storedData);
    });

    this.maqservice.getExistingAreaFeedback(this.username, this.projectId).subscribe(data => {
      this.Feedback = data.body;
      console.log("existing feedback");
      console.log(this.Feedback)

    });
    this.maqservice.getExistingQuestionFeedback(this.username, this.projectId).subscribe(data => {
      this.qFeedback = data.body;
      console.log("existing feedback");
      console.log(this.qFeedback)

    });

    this.maqservice.getAllQuestions().subscribe(data => {
      this.questionList = data.body;
      console.log("in areas-get all qstns.........................")
      console.log(this.questionList)
    });
  }

  checkIfAreaIsFilled(areaId: number) {
 
    let catBasedQuestions: any;
 
   // console.log("in check")
    for (let i = 0; i < this.storedData.length; i++) {
      if (i == 0) {
        if (areaId == this.storedData[0].areaId) {
          i++;
          return true;
        }
      }
      else if (areaId == this.storedData[i].areaId) {
         let count = 0;
        this.qcount = 0;
        this.existingQCount = 0;
        for (let c1 of this.storedData[i - 1].categories) {
          // console.log(this.Feedback)
          for (let fc of this.Feedback) {
            if (c1.categoryId == fc) {
              count++;
            }
          }
          for (let q of this.questionList) {
            if (q.category.categoryId == c1.categoryId) {
              this.qcount++;
            }
          }
          for (let qf of this.qFeedback) {
            if (c1.categoryId == qf.category.categoryId) {
              this.existingQCount++;
            }
          }
        }
        // console.log("counts...................................")
        // console.log(count);
        // console.log(this.existingQCount);
 
        if (this.storedData[i - 1].categories.length == count && this.existingQCount == this.qcount) {
          return true;
        }
        else {
          return false;
        }
      }
    }
  }
}