import { Component, OnInit } from '@angular/core';
import { DevopsmaqService } from 'src/app/shared/services/devopsmaq.service';
import { ActivatedRoute } from '@angular/router';
import {
  FormGroup,
  FormControl, FormBuilder, Validators
} from '@angular/forms';
import { Router } from '@angular/router';
import { TokenStorageService } from '../../shared/auth/token-storage.service';
@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {
  ProjectSelectionForm: FormGroup;
  storedData:any;
  projectId:number;
  abc:number;
  user: string;
  username:string;
  constructor(private maqservice: DevopsmaqService,private router:Router, private route: ActivatedRoute, private token: TokenStorageService) { }

  ngOnInit(){
    this.ProjectSelectionForm = new FormGroup(
      {
        projectId: new FormControl('')
      }
    );
    this.user=this.token.getUsername();
    this.maqservice.getUserProjectswithdb(this.user).subscribe(data => {
      this.storedData = data.body;
      console.log(this.storedData);
    });
   
  }
  onSubmit()
  {
    this.projectId=this.ProjectSelectionForm.get('projectId').value;
    window.sessionStorage.setItem('projectId', JSON.stringify(this.projectId));
    console.log("submitted");
    this.router.navigate(['/client/board']);
  }

}
