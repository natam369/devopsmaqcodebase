import { Component, OnInit } from '@angular/core';
import { TokenStorageService } from '../../shared/auth/token-storage.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  private roles: string[];
  public authority: string;
  info: any;
  isLoggedIn: boolean;
  constructor(private token: TokenStorageService) { }

  ngOnInit() {
    if (this.token.getToken()) {
      this.roles = this.token.getAuthorities();
      this.roles.every(role => {
        if (role === 'ROLE_ADMIN') {
          this.authority = 'admin';
          console.log(this.authority);
          return false;
        } else if (role === 'ROLE_VIEWER') {
          this.authority = 'viewer';
          console.log(this.authority);
          return false;
        }
        else if (role === 'ROLE_CLIENT') {
          this.authority = 'client';
          console.log(this.authority);
          return false;
        }
        this.authority = 'archi';
        console.log(this.authority);
        return true;
        
      });
      this.info = {
        token: this.token.getToken(),
        username: this.token.getUsername(),
        authorities: this.token.getAuthorities()
      };
    }
  }
}
