import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { DevopsmaqService } from 'src/app/shared/services/devopsmaq.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {
  storedData: any;
  areaId: 0;
  constructor(private maqservice: DevopsmaqService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.areaId = params['areaId'];
      this.maqservice.getCategoriesList(this.areaId).subscribe(data => {
        this.storedData = data;
        console.log(this.storedData);
      });
    });
  }

}
