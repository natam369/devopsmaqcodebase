import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormControl, FormBuilder, Validators, FormArray
} from '@angular/forms';
import { Router } from '@angular/router';
import { TokenStorageService } from '../../shared/auth/token-storage.service';
import { ConfirmedValidator } from './confirmed.validator';
import { DevopsmaqService } from 'src/app/shared/services/devopsmaq.service';
@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {
  oldpassword: string;
  newpassword: string;
  username: string;
  getData: any;
  isPasswordChangeFailed = false;
  isPasswordchanged = false;
  errorMessage = '';
  Credentials: FormGroup = new FormGroup({});
  constructor(private fb: FormBuilder,private router:Router, private tokenStorage: TokenStorageService, private maqservice: DevopsmaqService) {
    this.Credentials = fb.group({

      password: ['', [Validators.required]],

      currentpassword: ['', [Validators.required]],


      confirm_password: ['', [Validators.required]]

    }, {

      validator: ConfirmedValidator('password', 'confirm_password')

    })
  }

  ngOnInit() {
  }

  onSubmit() {
    this.username = this.tokenStorage.getUsername();
    this.oldpassword = this.Credentials.get('currentpassword').value;
    this.newpassword = this.Credentials.get('confirm_password').value;
    this.maqservice.changePassword(this.username, this.oldpassword, this.newpassword).subscribe(data => {
      this.getData = data
      this.isPasswordChangeFailed = false;
      this.isPasswordchanged = true;
      if (this.isPasswordchanged) {
        alert("password  changed successfully");
        window.sessionStorage.clear();
        // this.router.navigate(['/']);
        window.location.href = "";
        // this.router.navigate(['auth/login']);
      }
    },
      error => {
        console.log(error);
        this.errorMessage = error.error.message;
        console.log(this.errorMessage);
        this.isPasswordChangeFailed = true;
        if (this.isPasswordChangeFailed) {
          alert(this.errorMessage);
        }
      });

    this.Credentials.reset();
  }
  get f() {

    return this.Credentials.controls;

  }
}