import { Component, OnInit } from '@angular/core';
import { DevopsmaqService } from 'src/app/shared/services/devopsmaq.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewer',
  templateUrl: './viewer.component.html',
  styleUrls: ['./viewer.component.css']
})
export class ViewerComponent implements OnInit {
  accounts: any = ['acc1', 'acc2', 'acc3'];
  options = [1, 2, 3];
  optionSelected: any;
  clients: any;
  projects: any = [];
  ProjectSelectionForm: FormGroup;
  // projects1: any = ['11', '12', '13'];
  // projects2: any = ['21', '22', '23'];
  storedData: any;
  projectId: number;
  constructor(private maqservice: DevopsmaqService,private router:Router) { }

  ngOnInit() {
    this.ProjectSelectionForm = new FormGroup(
      {
        projectId: new FormControl(''),
        userId: new FormControl('')
      }
    );

    this.maqservice.getUsersListwithdb().subscribe(data => {
      this.clients = data.body;
      console.log(this.storedData);

    });
  }
  onOptionsSelected(event) {
    //alert(event);
    this.maqservice.getUserProjectswithdb(event).subscribe(data => {
      this.storedData = data.body;
      console.log(this.storedData);
      this.projects = this.storedData;
    });
  }
  onSubmit() {
    this.projectId = this.ProjectSelectionForm.get('projectId').value;
    console.log(this.ProjectSelectionForm.get("projectId").value);
    window.sessionStorage.setItem('projectId', JSON.stringify(this.projectId));
    console.log("submitted");
    this.router.navigate(['/client/board']);
  }
}
