import { Component, OnInit } from '@angular/core';
import { DevopsmaqService } from 'src/app/shared/services/devopsmaq.service';
import { ActivatedRoute } from '@angular/router';
import {
  FormGroup,
  FormControl, FormBuilder, Validators
} from '@angular/forms';
import { TokenStorageService } from '../../shared/auth/token-storage.service';
import { Router } from '@angular/router';
declare var jQuery: any;
@Component({
  selector: 'app-user-areas',
  templateUrl: './user-areas.component.html',
  styleUrls: ['./user-areas.component.css']
})
export class UserAreasComponent implements OnInit {
  user: string;
  projectName: string;
  storedData: any;
  projectId: number;
  userprojectId: number = 0;
  abc: number;
  getData: any;
  username: string;
  ProjectSelectionForm: FormGroup;
  constructor(private maqservice: DevopsmaqService, private route: ActivatedRoute, public router: Router, private token: TokenStorageService) { }

  ngOnInit() {
    this.ProjectSelectionForm = new FormGroup(
      {
        projectId: new FormControl(''),
        projectName: new FormControl('')
      }
    );

    this.user = this.route.snapshot.params['username'];
    console.log(this.user);
    this.maqservice.getUserProjects(this.user).subscribe(data => {
      this.storedData = data;
      console.log(this.storedData);
    });

    (function ($) {
      $(document).ready(function () {

        // $("#displayField").prop('disabled', true);
        $("#displayField").hide();
        $("#newproject").hide();

        $("#projects").click(function () {
          if ($("#projects").val() == "others") {
            // $("#displayField").prop('disabled', false);
            $("#displayField").show();
            $("#newproject").show();
            $("#displayField").attr("name", "name");
            $("#projects").attr("name", "");
          }
          else {
            // $("#displayField").prop('disabled', true);
            $("#displayField").hide();
            $("#newproject").hide();
            $("#projects").attr("name", "name");
            $("#displayField").attr("name", "");
          }
        });

      });
    })(jQuery);
  }

  onSubmit() {

    // if (this.ProjectSelectionForm.get('projectId').value === "others") {
    //   console.log(this.ProjectSelectionForm.get('projectName').value);
    //   this.username = this.token.getUsername();
    //   this.maqservice.addUserProject(this.ProjectSelectionForm.get('projectName').value, this.username).subscribe(data => {
    //     this.getData = data.body;
    //     window.sessionStorage.setItem('projectId', JSON.stringify(this.getData.projectId));
    //     console.log(window.sessionStorage.getItem('projectId'));
    //   });
    // }
    // else {

    this.projectId = this.ProjectSelectionForm.get('projectId').value;
    window.sessionStorage.setItem('projectId', JSON.stringify(this.projectId));
    this.maqservice.getUserProjects(this.user).subscribe(data => {
      this.storedData = data.body;
      console.log(this.storedData);
      for (let i = 0; i < data.body.length; i++) {
        if (data.body[i].projectId == this.projectId) {
          console.log("projects equal" + data.body[i].projectId + this.projectId);

          window.sessionStorage.setItem('projectName', data.body[i].projectName);
        }
      }
    });
    
    // }
    //window.sessionStorage.setItem('projectName',this.projectName);
    // window.location.reload();
    this.router.navigate(['/areas']);
   // window.location.reload();
  }
}



