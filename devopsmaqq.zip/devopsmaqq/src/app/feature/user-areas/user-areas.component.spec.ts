import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAreasComponent } from './user-areas.component';

describe('UserAreasComponent', () => {
  let component: UserAreasComponent;
  let fixture: ComponentFixture<UserAreasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserAreasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAreasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
