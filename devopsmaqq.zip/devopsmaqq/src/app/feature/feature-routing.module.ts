import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { AdduserComponent } from './admin/adduser/adduser.component';
import { AddprojectComponent } from './admin/addproject/addproject.component';
import { RemoveuserComponent } from './admin/removeuser/removeuser.component';
import { RemoveprojectComponent } from './admin/removeproject/removeproject.component';
import { LogoutComponent } from './logout/logout.component';
import { UserAreasComponent } from './user-areas/user-areas.component';
import { AdminComponent } from './admin/admin.component';
import { RouterGuardService as RoleGuard } from '../shared/auth/router-guard.service';
import { AccessdeniedComponent } from './accessdenied/accessdenied.component';
import { ErrorComponent } from './error/error.component';
import { AreasComponent } from './areas/areas.component';
import { CategoriesComponent } from './categories/categories.component';
import { QuestionsComponent } from './questions/questions.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ScorecardComponent } from './scorecard/scorecard.component';
import { AssignarchitectComponent } from './admin/assignarchitect/assignarchitect.component';
import { AddprojectandassignComponent } from './admin/addprojectandassign/addprojectandassign.component';
import { ClientComponent } from './client/client.component';
import { ViewerComponent } from './viewer/viewer.component';
import { ClientboardComponent } from './clientboard/clientboard.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'auth/login', component: LoginComponent },
  { path: 'adduser', component: AdduserComponent },
  { path: 'addproject', component: AddprojectComponent },
  { path: 'deluser', component: RemoveuserComponent },
  { path: 'delproject', component: RemoveprojectComponent },
  { path: 'assign', component: AssignarchitectComponent },
  { path: 'add&assign', component: AddprojectandassignComponent },
  { path: 'auth/logout', component: LogoutComponent },
  { path: 'ddashboard', component: DashboardComponent },
  { path: 'client', component: ClientComponent },
  { path: 'viewer', component: ViewerComponent },
  { path: 'scorecard', component: ScorecardComponent },
  { path: 'client/board', component: ClientboardComponent },
  { path: 'password', component: ResetpasswordComponent },
  {
    path: 'user/:username', component: UserAreasComponent, canActivate: [RoleGuard],
    data: {
      expectedRole: ['admin', 'user']
    }
  },
  {
    path: 'accessdenied',
    component: AccessdeniedComponent
  },
  {
    path: 'admin', component: AdminComponent, canActivate: [RoleGuard],
    data: {
      expectedRole: ['admin']
    }
  },
  {
    path: 'areas',
    component: AreasComponent, children:
      [
        {
          path: 'categories/:areaId', component: CategoriesComponent, children:
            [
              {
                path: 'questions/:categoryId', component: QuestionsComponent
              }
            ]
        }
      ]
  },
  {
    path: '**', component: ErrorComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FeatureRoutingModule { }
