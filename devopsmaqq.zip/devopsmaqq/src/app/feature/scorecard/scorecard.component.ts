import { Component, OnInit } from '@angular/core';
import { DevopsmaqService } from 'src/app/shared/services/devopsmaq.service';
@Component({
  selector: 'app-scorecard',
  templateUrl: './scorecard.component.html',
  styleUrls: ['./scorecard.component.css']
})
export class ScorecardComponent implements OnInit {
  areaScoreCard:any;
  categoryScoreCard: any;
  dashboard: any;
  abc: number
  constructor(private maqService: DevopsmaqService) { }

  ngOnInit(): void {
    console.log(window.sessionStorage.getItem('projectId'));
    this.abc = JSON.parse(window.sessionStorage.getItem('projectId'));
    this.maqService.getCatScore(this.abc)
      .subscribe(data => {
        this.categoryScoreCard = data.body;
        console.log(this.categoryScoreCard);
      });

    this.maqService.getDashboardScore(this.abc)
      .subscribe(data => {
        this.dashboard = data.body;
        console.log(this.dashboard);
      });

    this.maqService.getAreaScore(this.abc)
      .subscribe(data => {
        this.areaScoreCard = data.body;
        console.log(this.areaScoreCard);
      });

  }

}
