import { Component, OnInit, ViewChildren, ElementRef, QueryList } from '@angular/core';
import { Chart } from 'chart.js';
import { DevopsmaqService } from 'src/app/shared/services/devopsmaq.service';
import { TokenStorageService } from '../../shared/auth/token-storage.service';
const baseConfig: Chart.ChartConfiguration = {
  type: 'doughnut',
  options: {
    responsive: true,
    legend: {
      display: false
    },
    cutoutPercentage: 65,
    tooltips: {
      filter: function (data) {
        var label = data.index;
        // if (label) return data;
      }
    }
  }
};
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  @ViewChildren('pr_chart', { read: ElementRef }) chartElementRefs: QueryList<ElementRef>;
  @ViewChildren('pr_chart1', { read: ElementRef }) chartElementRefss: QueryList<ElementRef>;


  constructor(private token: TokenStorageService, private maqservice: DevopsmaqService) { }
  categoryScoreCardList: any;
  chartData: Chart.ChartData[] = [];
  chartData1: Chart.ChartData[] = [];
  areascores: number[] = [];
  names: string[] = ['Define and Plan', 'Code,Build,Integrate', 'Test', 'Release and Deploy', 'Operate', 'People,Culture and Collaboration'];
  sum = 0;
  abc: number;
  projectid: number;
  values: any[] = [];
  ngOnInit() {
    console.log(window.sessionStorage.getItem('projectId'));
    this.abc = JSON.parse(window.sessionStorage.getItem('projectId'));
    this.maqservice.getCategoryScore(this.abc).subscribe(data => {
      this.categoryScoreCardList = data;
      console.log(data);
      for (let i = 0; i < this.categoryScoreCardList.length; i++) {
        for (let j = 0; j < this.categoryScoreCardList[i].length; j++) {
          // textCenter(this.categoryScoreCardList[i][j].categoryScore);
          console.log(this.categoryScoreCardList[i][j]);

          this.sum = this.sum + this.categoryScoreCardList[i][j].categoryScore;
          var pie = {
            type: 'doughnut',
            lables: ['myvalue', ''],
            datasets: [{
              data: [this.categoryScoreCardList[i][j].categoryScore, 5 - this.categoryScoreCardList[i][j].categoryScore],
              backgroundColor: [
                "#FF6384",
                "#ffffff"
              ],
              hoverBackgroundColor: [
                "#FF6384",
                "#ffffff"
              ],
              hoverBorderColor: [
                "#FF6384",
                "#ffffff"
              ],
            }]
          };
          // console.log(pie);
          this.chartData.push(pie);

        }
        this.sum = this.sum / this.categoryScoreCardList[i].length;
        console.log(this.sum.toFixed(2));
        this.areascores.push(this.sum);
        this.sum = 0;
      }
      console.log(this.areascores);
      const x = {
        a: this.areascores,
        b: this.names
      }
      this.values.push(x);
      console.log(this.values);
      this.create();
    });
    this.ngAfterViewInit();

  }
  create() {
    for (let j = 0; j < this.areascores.length; j++) {
      
      var pie = {
        type: 'doughnut',
        lables: ['myvalue', ''],
        datasets: [{
          data: [this.areascores[j], 5 - this.areascores[j]],
          backgroundColor: [
            "#4cd3c2",
            "#ffffff"
          ],
          hoverBackgroundColor: [
            "#4cd3c2",
            "#ffffff"
          ],
          hoverBorderColor: [
            "#4cd3c2",
            "#ffffff"
          ],
        }]
      };
      // console.log(pie);
      this.chartData1.push(pie);
    }

  }
  charts: Chart[] = [];
  ngAfterViewInit() {
    this.charts = this.chartElementRefs.map((chartElementRef, index) => {
      const config = Object.assign({}, baseConfig, { data: this.chartData[index] });

      return new Chart(chartElementRef.nativeElement, config);
    });
    this.charts = this.chartElementRefss.map((chartElementRef, index) => {
      const config = Object.assign({}, baseConfig, { data: this.chartData1[index] });

      return new Chart(chartElementRef.nativeElement, config);
    });

  }
}
