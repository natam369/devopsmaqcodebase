import { Component, OnInit } from '@angular/core';
import { TokenStorageService } from './shared/auth/token-storage.service';
import { Router, CanActivate, ActivatedRouteSnapshot } from '@angular/router';
import { AuthService } from './shared/auth/auth.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  private roles: string[];
  public authority: string;
  info: any;
  button: string = "";
  isLoggedIn: boolean;
  username: string;
  projectName = "";
  constructor(private tokenStorage: TokenStorageService, public router: Router, private authservice: AuthService) { }
  ngOnInit() {
    this.projectName = window.sessionStorage.getItem('projectName');
    if (this.tokenStorage.getToken()) {
      this.roles = this.tokenStorage.getAuthorities();
      this.roles.every(role => {
        if (role === 'ROLE_ADMIN') {
          this.authority = 'admin';
          console.log(this.authority);
          return false;
        } else if (role === 'ROLE_VIEWER') {
          this.authority = 'viewer';
          console.log(this.authority);
          return false;
        }
        else if (role === 'ROLE_CLIENT') {
          this.authority = 'client';
          console.log(this.authority);
          return false;
        }
        this.authority = 'archi';
        console.log(this.authority);
        return true;
      });
      this.info = {
        token: this.tokenStorage.getToken(),
        username: this.tokenStorage.getUsername(),
        authorities: this.tokenStorage.getAuthorities()
      };
    }
    this.username = this.tokenStorage.getUsername();
    this.isLoggedIn = this.authservice.isAuthenticated();
    console.log(this.isLoggedIn);
    console.log(this.info);
  }
  logout() {
    window.sessionStorage.clear();
    // this.router.navigate(['/']);
    window.location.href = "";
  }
  random() {
    this.button = this.projectName;
  }
  architect() {
    //console.log("ss")
    this.router.navigate(["/user/" + this.username])
    //window.location.reload();
  }
  dashBoards() {
    this.router.navigate(['/viewer']);
  }
}
