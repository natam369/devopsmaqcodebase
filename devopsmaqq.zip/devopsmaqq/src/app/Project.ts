export class Project{

    projectId:number;
    projectName : string;

    constructor(projectName)
    {
      //  this.projectId=projectId;
        this.projectName=projectName;

    }
    
}