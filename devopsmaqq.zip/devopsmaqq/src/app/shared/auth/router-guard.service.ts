import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot } from '@angular/router';
import { AuthService } from './auth.service';
import { TokenStorageService } from '../auth/token-storage.service';
@Injectable({
  providedIn: 'root'
})
export class RouterGuardService {
  private roles: string[];
  private authority: string;
  constructor(public auth: AuthService, public router: Router, private tokenStorage: TokenStorageService) { }
  canActivate(route: ActivatedRouteSnapshot): boolean {

    let expectedRoleArray = route.data;
    expectedRoleArray = expectedRoleArray.expectedRole;
    let expectedRole = '';

    const token = this.tokenStorage.getToken();
    if (this.tokenStorage.getToken()) {
      this.roles = this.tokenStorage.getAuthorities();
      this.roles.every(role => {
        if (role === 'ROLE_ADMIN') {
          this.authority = 'admin';
          return false;
        } else if (role === 'ROLE_PM') {
          this.authority = 'pm';
          return false;
        }
        this.authority = 'user';
        return true;
      });
    }

    for (let i = 0; i < expectedRoleArray.length; i++) {
      if (expectedRoleArray[i] == this.authority) {
        console.log("Roles Matched");
        expectedRole = this.authority;
      }
    }

    if (this.auth.isAuthenticated() && this.authority == expectedRole) {
      console.log("User permitted to access the route");
      return true;
    }
    this.router.navigate(['/accessdenied']);
    return false;

  }
}
