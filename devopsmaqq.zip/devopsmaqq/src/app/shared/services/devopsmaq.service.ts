import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Project } from '../../Project';
@Injectable({
  providedIn: 'root'
})
export class DevopsmaqService {
  private header = new HttpHeaders({ 'content-type': 'application/json' });
  private baseUrl = 'http://localhost:8080/devopsmaq';
  constructor(private http: HttpClient) { }
  public getallUsersList(): Observable<any> {
    console.log("inside get users service");
    return this.http.get(`${this.baseUrl}` + `/getallusers`);
  }
  public addProject(project, userId: number, architectId: number): Observable<any> {
    return this.http.post(`${this.baseUrl}` + `/project/` + userId + `/` + architectId, project);
  }
  public getUsersList(): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getusers`);
  }
  public getUsersListwithdb(): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getusersForDb`);
  }

  public getProjectsList(): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getprojects`);
  }
  public getArchitectList(): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/archis`);
  }
  public getAreasList(): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getareas`);
  }
  public AssignArchitect(projectId: number, userId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/assign/` + projectId + `/` + userId);
  }
  public deleteUser(id) {
    return this.http.delete(`${this.baseUrl}` + `/delete-user/` + id);
  }
  public deleteProject(projectId: number) {
    return this.http.delete(`${this.baseUrl}` + `/delete-project/` + projectId);
  }
  public saveProject(id: number, project: Project) {
    return this.http.post(`${this.baseUrl}` + `/project/` + id, project);
  }

  public getCategoriesList(areaId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getcategories/` + areaId);
  }
  public getQuestionsList(categoryId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getquestions/` + categoryId);
  }
  public getUserProjects(username: string): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getuserprojects/` + username);
  }
  public getUserProjectswithdb(username: string): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getuserprojectsForDb/` + username);
  }
  public saveFeedBack(feed, username: string, projectId: number) {
    return this.http.post(`${this.baseUrl}` + `/feedback/save/` + username + `/` + projectId, feed);
  }
  public getCategoryScore(projectId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getCatScores/` + projectId);

  }
  getAreaScore(projectId: number): Observable<any> {


    return this.http.get(`${this.baseUrl}` + `/getAreaScore/` + projectId);

  }
  getCatScore(projectId: number): Observable<any> {

    return this.http.get(`${this.baseUrl}` + `/getCatScore/` + projectId);

  }

  getDashboardScore(projectId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getOverallScores/` + projectId);
  }
  public addUserProject(projectName: string, username: string): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/userproject/` + projectName + `/` + username);

  }
  public getExistingAreaFeedback(username: string, projectId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getAreaFeedback/` + username + `/` + projectId);
  }
  public getExistingQuestionFeedback(username: string, projectId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getQuestionFeedback/` + username + `/` + projectId);
  }
  public getExistingFeedback(username: string, projectId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getExistingFeedback/` + username + `/` + projectId);
  }
  public getAllQuestions(): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getAllQuestions`);
  }

  public getAllQuestionsForPatchValues(username: string, projectId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/getAllQuestionsForPatchValue/` + username + `/` + projectId);
  }

  public calculateScores(projectId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}` + "/calculate/" + projectId);
  }
  public changePassword(username: string, oldPassword: string, password: string) {
    return this.http.get(`${this.baseUrl}` + `/changePassword/` + username + `/` + oldPassword + `/` + password);
  }
}
