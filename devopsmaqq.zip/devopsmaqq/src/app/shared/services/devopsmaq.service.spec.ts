import { TestBed } from '@angular/core/testing';

import { DevopsmaqService } from './devopsmaq.service';

describe('DevopsmaqService', () => {
  let service: DevopsmaqService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DevopsmaqService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
