export class User {
    userId: number;
    username: string;
    password: string;
   // active: boolean;
}