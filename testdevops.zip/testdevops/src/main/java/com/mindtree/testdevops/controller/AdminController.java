package com.mindtree.testdevops.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.testdevops.apiResponse.ApiResponse;
import com.mindtree.testdevops.entity.Project;
import com.mindtree.testdevops.entity.User;
import com.mindtree.testdevops.repository.AreaRepository;
import com.mindtree.testdevops.repository.CategoryRepository;
import com.mindtree.testdevops.repository.FeedbackRepository;
import com.mindtree.testdevops.repository.ProjectRepository;
import com.mindtree.testdevops.repository.QuestionRepository;
import com.mindtree.testdevops.repository.UserRepository;
import com.mindtree.testdevops.service.AreaService;
import com.mindtree.testdevops.service.CategoryService;
import com.mindtree.testdevops.service.FeedbackService;
import com.mindtree.testdevops.service.ProjectService;
import com.mindtree.testdevops.service.QuestionService;
import com.mindtree.testdevops.service.UserService;

@SpringBootApplication
@RestController
@RequestMapping("/devopsmaq")
@CrossOrigin()
public class AdminController {

	@Autowired
	UserService userservice;

	@Autowired
	ProjectService projectService;

	@Autowired
	AreaService areaService;

	@Autowired
	CategoryService categoryService;

	@Autowired
	QuestionService questionService;

	@Autowired
	FeedbackService feedbackService;

	/* Start Repo Autowired */

	@Autowired
	UserRepository userRepo;

	@Autowired
	ProjectRepository prepo;

	@Autowired
	AreaRepository areaRepo;

	@Autowired
	CategoryRepository categoryRepo;

	@Autowired
	QuestionRepository questionRepo;

	@Autowired
	FeedbackRepository feedbackRepo;

	/* End Repo Autowired */

	// create,get,delete users............................................

	@PostMapping(value = "/create")
	public User adduser(@RequestBody User user) {

		System.out.println("inside user creation");
		return userservice.saveUser(user);

	}

	@GetMapping(value = "/getusers")

	public ResponseEntity<ApiResponse> getusers() {
		List<User> users = userservice.getUsers();
		return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse("success", false, users, HttpStatus.OK));

	}

	@GetMapping(value = "/getallusers")

	public ResponseEntity<ApiResponse> getallusers() {
		List<User> users = userservice.getAllUsers();
		return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse("success", false, users, HttpStatus.OK));

	}

	@DeleteMapping(value = "/delete-user/{id}")

	public ResponseEntity<ApiResponse> deletetheuser(@PathVariable("id") int id) {
		List<User> usersNow = userservice.removeuser(id);
		return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse("success", false, usersNow, HttpStatus.OK));
	}

	// create,delete,get projects.....................................
	@DeleteMapping(value = "/delete-project/{id}")

	public ResponseEntity<ApiResponse> deletetheproject(@PathVariable("id") int projectId) {
		System.out.println(prepo.findById(projectId).get().getProjectName());
		List<Project> projectsNow = projectService.deleteProject(projectId);
		return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse("success", false, projectsNow, HttpStatus.OK));
	}

	@GetMapping(value = "/getprojects")

	public ResponseEntity<ApiResponse> getallprojects() {
		List<Project> projects = projectService.getProjects();
		return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse("success", false, projects, HttpStatus.OK));

	}


	@RequestMapping(value = "/archis")
	public ResponseEntity<ApiResponse> getArchitectsfromDb() {
		// return projectService.getArchitects();
		return ResponseEntity.status(HttpStatus.OK)
				.body(new ApiResponse("success", false, projectService.getArchitects(), HttpStatus.OK));
	}

//	@PostMapping(value = "/project/{id}/{archiId}")
//	public ResponseEntity<ApiResponse> addproject(@PathVariable("id") int userid, @PathVariable("archiId") int archiId,
//			@RequestBody Project project) {
//		Project projectsaved = projectService.saveProject(userid, project, archiId);
//		return ResponseEntity.status(HttpStatus.OK)
//				.body(new ApiResponse("success", false, projectsaved, HttpStatus.OK));
//
//	}
	@PostMapping(value = "/project/{id}/{archiId}")
	public ResponseEntity<ApiResponse> addproject(@PathVariable("id") int userid, @PathVariable("archiId") int archiId,
            @RequestBody Project project) {
        Project projectsaved = projectService.saveProject(userid, project, archiId);
        return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse(projectsaved, "assinged successfully"));

    }
}
