package com.mindtree.testdevops.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
@Entity
public class Feedback {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int feedbackId;
	@OneToOne(cascade=CascadeType.PERSIST, fetch = FetchType.LAZY)
	private User user;
	@OneToOne
	private Project project;
	@ManyToOne
	@OnDelete(action = OnDeleteAction.CASCADE)
	private Area area;
	@ManyToOne
	@OnDelete(action = OnDeleteAction.CASCADE)
	private Category category;
	@OneToOne
	private Question question;
	private int response;
	private String remarks;

	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Feedback(int feedbackId, User user, Project project, Area area, Category category, Question question, int response,
			String remarks) {
		super();
		this.feedbackId= feedbackId;
		this.user = user;
		this.project = project;
		this.area = area;
		this.category = category;
		this.question = question;
		this.response = response;
		this.remarks = remarks;
	}

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public int getResponse() {
		return response;
	}

	public void setResponse(int response) {
		this.response = response;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
