package com.mindtree.testdevops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestdevopsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestdevopsApplication.class, args);
	}

}
