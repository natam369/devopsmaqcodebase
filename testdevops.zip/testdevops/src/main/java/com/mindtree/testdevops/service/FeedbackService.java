package com.mindtree.testdevops.service;

import java.util.List;

import com.mindtree.testdevops.angularclasses.FeedBackFormValue;
import com.mindtree.testdevops.dto.ExistingFeedback;
import com.mindtree.testdevops.entity.Feedback;
import com.mindtree.testdevops.entity.Question;

public interface FeedbackService {

	String saveFeedback(FeedBackFormValue feedback, String username, int projectId);

	List<Integer> getExistingAreaFeedback(String username, int projectId);

	List<Question> getExistingQuestionFeedback(String username, int projectId);

	List<Feedback> getExistingFeedback(String username, int projectId);

	// List<ExistingFeedback> getAllForPatchValues(String username, int projectId);
}
