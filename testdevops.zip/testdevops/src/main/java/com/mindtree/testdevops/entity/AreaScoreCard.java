package com.mindtree.testdevops.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class AreaScoreCard {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int asid;
	@OneToOne
	Area area;
	@OneToOne
	Project project;
	@Column( columnDefinition = "Decimal(10,2)")
	double weightedAreaScore;

	public AreaScoreCard() {
		super();
	}

	public int getAsid() {
		return asid;
	}

	public void setAsid(int asid) {
		this.asid = asid;
	}

	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public double getWeightedAreaScore() {
		return weightedAreaScore;
	}

	public void setWeightedAreaScore(double weightedAreaScore) {
		this.weightedAreaScore = weightedAreaScore;
	}

	
	
}
