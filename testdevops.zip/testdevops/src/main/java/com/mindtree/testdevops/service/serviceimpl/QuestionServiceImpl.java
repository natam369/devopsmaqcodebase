package com.mindtree.testdevops.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.testdevops.dto.ExistingFeedback;
import com.mindtree.testdevops.entity.Feedback;
import com.mindtree.testdevops.entity.Project;
import com.mindtree.testdevops.entity.Question;
import com.mindtree.testdevops.entity.User;
import com.mindtree.testdevops.repository.FeedbackRepository;
import com.mindtree.testdevops.repository.ProjectRepository;
import com.mindtree.testdevops.repository.QuestionRepository;
import com.mindtree.testdevops.repository.UserRepository;
import com.mindtree.testdevops.service.QuestionService;

@Service
public class QuestionServiceImpl implements QuestionService {

	@Autowired
	QuestionRepository qrepo;

	@Autowired
	FeedbackRepository feedbackRepo;

	@Autowired
	UserRepository userRepo;

	@Autowired
	ProjectRepository projectRepo;

	@Override
	public Question getQuestion(int questionId) {

		return qrepo.getOne(questionId);
	}

	@Override
	public List<ExistingFeedback> getAllForPatchValues(String username, int projectId) {

		List<Question> q = qrepo.findAll();

		User u = userRepo.findByUsername(username).get();
		Project p = projectRepo.getOne(projectId);
		List<ExistingFeedback> setFeedbacks = new ArrayList<ExistingFeedback>();
		for (Question q1 : q) {
			int c = 0;
			ExistingFeedback feed = new ExistingFeedback();
			for (Feedback f : feedbackRepo.findAll()) {

				if (f.getQuestion().getQuestionId() == q1.getQuestionId() && f.getProject().getProjectId() == projectId
						&& f.getUser() == u) {
					feed.setCategory(f.getCategory());
					feed.setProject(f.getProject());
					feed.setQuestion(f.getQuestion());
					feed.setRemarks(f.getRemarks());
					feed.setResponse(f.getResponse());
					feed.setArea(f.getArea());
					feed.setUser(f.getUser());
					setFeedbacks.add(feed);
					c++;
					break;
				}

			}
			if (c == 0) {
				feed.setUser(u);
				feed.setProject(p);
				feed.setCategory(q1.getCategory());
				feed.setArea(q1.getCategory().getArea());
				feed.setQuestion(q1);
				feed.setResponse(6);
				setFeedbacks.add(feed);
			}
		}
		for (ExistingFeedback f2 : setFeedbacks) {
			System.out.println(f2.getQuestion().getQuestionId() + ":" + f2.getResponse());
		}
		System.out.println(setFeedbacks.size());
		return setFeedbacks;
	}

	@Override
	public List<Question> getAllQuestions() {

		return qrepo.findAll();
	}
}
