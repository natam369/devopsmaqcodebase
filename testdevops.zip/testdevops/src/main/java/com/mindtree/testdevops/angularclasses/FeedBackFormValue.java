package com.mindtree.testdevops.angularclasses;

import java.util.List;

public class FeedBackFormValue {
	
	private List<solutions> solution;

	public FeedBackFormValue(List<solutions> solution) {
		super();
		this.solution = solution;
	}

	public List<solutions> getSolution() {
		return solution;
	}

	public void setSolution(List<solutions> solution) {
		this.solution = solution;
	}

	public FeedBackFormValue() {
		super();
		// TODO Auto-generated constructor stub
	}

	

}
