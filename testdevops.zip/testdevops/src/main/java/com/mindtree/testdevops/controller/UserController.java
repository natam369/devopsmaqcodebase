package com.mindtree.testdevops.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.testdevops.angularclasses.FeedBackFormValue;
import com.mindtree.testdevops.apiResponse.ApiResponse;
import com.mindtree.testdevops.dto.ExistingFeedback;
import com.mindtree.testdevops.entity.Area;
import com.mindtree.testdevops.entity.AreaScoreCard;
import com.mindtree.testdevops.entity.Category;
import com.mindtree.testdevops.entity.CategoryScoreCard;
import com.mindtree.testdevops.entity.Dashboard;
import com.mindtree.testdevops.entity.Feedback;
import com.mindtree.testdevops.entity.Project;
import com.mindtree.testdevops.entity.Question;
import com.mindtree.testdevops.entity.User;
import com.mindtree.testdevops.exception.DashboardDoesNotExistException;
import com.mindtree.testdevops.exception.WrongPasswordException;
import com.mindtree.testdevops.repository.AreaRepository;
import com.mindtree.testdevops.repository.CategoryRepository;
import com.mindtree.testdevops.repository.FeedbackRepository;
import com.mindtree.testdevops.repository.ProjectRepository;
import com.mindtree.testdevops.repository.QuestionRepository;
import com.mindtree.testdevops.repository.UserRepository;
import com.mindtree.testdevops.service.AreaService;
import com.mindtree.testdevops.service.CategoryService;
import com.mindtree.testdevops.service.DashboardService;
import com.mindtree.testdevops.service.FeedbackService;
import com.mindtree.testdevops.service.ProjectService;
import com.mindtree.testdevops.service.QuestionService;
import com.mindtree.testdevops.service.UserService;

@SpringBootApplication
@RestController
@RequestMapping("/devopsmaq")
@CrossOrigin(origins = "*", maxAge = 3600)
public class UserController {

	@Autowired
	UserService userservice;

	@Autowired
	ProjectService projectService;

	@Autowired
	AreaService areaService;

	@Autowired
	CategoryService categoryService;

	@Autowired
	QuestionService questionService;

	@Autowired
	FeedbackService feedbackService;

	/* Start Repo Autowired */

	@Autowired
	UserRepository userRepo;

	@Autowired
	ProjectRepository prepo;

	@Autowired
	AreaRepository areaRepo;

	@Autowired
	CategoryRepository categoryRepo;

	@Autowired
	QuestionRepository questionRepo;

	@Autowired
	FeedbackRepository feedbackRepo;

	@Autowired
	DashboardService dbservice;

	/* End Repo Autowired */

	// get areas,categories,qstns..................................................

	@GetMapping(value = "/getareas")
	public ResponseEntity<ApiResponse> getareas() {
		List<Area> areas = userservice.getAreas();
		return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse("success", false, areas, HttpStatus.OK));
	}

	@GetMapping(value = "/getcategories/{areaId}")
	public ResponseEntity<ApiResponse> getcategory(@PathVariable("areaId") int areaId) {
		List<Category> categories = userservice.getCategories(areaId);
		return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse("success", false, categories, HttpStatus.OK));
	}

	@GetMapping(value = "/getquestions/{categoryId}")
	public ResponseEntity<ApiResponse> getquestion(@PathVariable("categoryId") int categoryId) {
		List<Question> questions = userservice.getQuestions(categoryId);
		return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse("success", false, questions, HttpStatus.OK));
	}

	@PostMapping(value = "/feedback/save/{username}/{projectId}")

	public ResponseEntity<ApiResponse> saveFeed(@RequestBody FeedBackFormValue feedback,
			@PathVariable("username") String username, @PathVariable("projectId") int projectId) {
		String s = null;

		System.out.println(feedbackService.saveFeedback(feedback, username, projectId));

		List<Question> questionCount = new ArrayList<Question>();

		for (Feedback feedbackcheck : feedbackRepo.findAll()) {

			if (feedbackcheck.getProject().getProjectId() == projectId) {

				questionCount.add(feedbackcheck.getQuestion());

			}

		}

		System.out.println(s);

		return ResponseEntity.status(HttpStatus.OK)

				.body(new ApiResponse("success", false, feedback.getSolution().size(), HttpStatus.OK));

	}

	@GetMapping(value = "/getuserprojects/{username}")
	public ResponseEntity<ApiResponse> getProjects(@PathVariable("username") String username) {
		System.out.println(username);
		List<Project> projects = userservice.getUserProjects(username);
		return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse("success", false, projects, HttpStatus.OK));
	}

	@RequestMapping("/calculate/{projectId}")
	public String calculate(@PathVariable int projectId) {
		String s = dbservice.calculateCatScore(projectId);
		s += "/" + dbservice.calculateAreaScore(projectId);
		s += "/" + dbservice.calculateOverAllScore(projectId);
		return s;
	}

	@RequestMapping("/getCatScore/{projectId}")
	public ResponseEntity<ApiResponse> getCatScore(@PathVariable int projectId) {
		return ResponseEntity.status(HttpStatus.OK)
				.body(new ApiResponse("success", false, dbservice.findAll(projectId), HttpStatus.OK));

	}

	@RequestMapping("/getCatScores/{projectId}")
	public List<List<CategoryScoreCard>> getCatScores(@PathVariable int projectId) {
		return dbservice.findAllcat(projectId);

	}

	@RequestMapping("/getAreaScore/{projectId}")
	public ResponseEntity<ApiResponse> getAreaScore(@PathVariable int projectId) {
		return ResponseEntity.status(HttpStatus.OK)
				.body(new ApiResponse("success", false, dbservice.findAllAreaScores(projectId), HttpStatus.OK));
	}

	@RequestMapping("/getscores/{projectId}")
	public ResponseEntity<ApiResponse> getScores(@PathVariable int projectId) {
		return ResponseEntity.status(HttpStatus.OK)
				.body(new ApiResponse("success", false, dbservice.getCatScores(projectId), HttpStatus.OK));
	}

	@RequestMapping("/getOverallScores/{projectId}")
	public ResponseEntity<ApiResponse> getDashboardScore(@PathVariable int projectId) {

		return ResponseEntity.status(HttpStatus.OK)
				.body(new ApiResponse("success", false, dbservice.getDashboardScore(projectId), HttpStatus.OK));
	}


	@RequestMapping(value = "/getAreaFeedback/{username}/{projectId}")
	public ResponseEntity<ApiResponse> getExistingAreaFeedback(@PathVariable String username,
			@PathVariable int projectId) {

		return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse("success", false,
				feedbackService.getExistingAreaFeedback(username, projectId), HttpStatus.OK));
	}


	@RequestMapping(value = "/getQuestionFeedback/{username}/{projectId}")
	public ResponseEntity<ApiResponse> getExistingQuestion(@PathVariable String username, @PathVariable int projectId) {
		return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse("success", false,
				feedbackService.getExistingQuestionFeedback(username, projectId), HttpStatus.OK));
	}


	@GetMapping(value = "/getExistingFeedback/{username}/{projectId}")
	public ResponseEntity<ApiResponse> getExistingFeedback(@PathVariable String username, @PathVariable int projectId) {
		return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse("success", false,
				feedbackService.getExistingFeedback(username, projectId), HttpStatus.OK));
	}

	@GetMapping(value = "/getAllQuestionsForPatchValue/{username}/{projectId}")
	public List<ExistingFeedback> setPatchValues(@PathVariable String username, @PathVariable int projectId) {
		return questionService.getAllForPatchValues(username, projectId);
	}

	@RequestMapping("/getAllQuestions")
	public ResponseEntity<ApiResponse> getAllQuestions() {
		return ResponseEntity.status(HttpStatus.OK)
				.body(new ApiResponse("success", false, questionService.getAllQuestions(), HttpStatus.OK));
	}

	@GetMapping("/getusersForDb")
    public ResponseEntity<ApiResponse> getUsersForProject() {

 

        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse("success", false, userservice.getUsersForDb(), HttpStatus.OK));
    }

 @GetMapping("/getuserprojectsForDb/{username}")
    public ResponseEntity<ApiResponse> getUsersForProjectForDb(@PathVariable("username") String username) {
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse("success", false, projectService.getUserProjectsForDb(username), HttpStatus.OK));
    }
 @RequestMapping("/changePassword/{username}/{oldPassword}/{password}")
 public ResponseEntity<ApiResponse> changePassword(@PathVariable String username,@PathVariable String oldPassword,@PathVariable String password) throws WrongPasswordException {
     return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse("success", false,
             userservice.changePassword(username, oldPassword, password), HttpStatus.OK));
 }

}
