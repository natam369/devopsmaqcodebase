package com.mindtree.testdevops.service;

public interface CategoryService {

}
