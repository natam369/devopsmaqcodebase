package com.mindtree.testdevops.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.testdevops.entity.Dashboard;

public interface DashBoardRepository extends JpaRepository<Dashboard, Integer>{

}
