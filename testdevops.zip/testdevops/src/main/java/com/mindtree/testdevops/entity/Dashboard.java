package com.mindtree.testdevops.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Dashboard {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int did;
	@OneToOne
	Project project;
	@Column( columnDefinition = "Decimal(10,2)")
	double overAllScore;
	@Column( columnDefinition = "Decimal(10,2)")
	double overAllMaturity;

	public Dashboard() {
		super();
	}

	public int getDid() {
		return did;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public double getOverAllScore() {
		return overAllScore;
	}

	public void setOverAllScore(double overAllScore) {
		this.overAllScore = overAllScore;
	}

	public double getOverAllMaturity() {
		return overAllMaturity;
	}

	public void setOverAllMaturity(double overAllMaturity) {
		this.overAllMaturity = overAllMaturity;
	}

}
