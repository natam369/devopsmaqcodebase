package com.mindtree.testdevops.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Category {

	@Id
	private int categoryId;
	private String categoryName;
	private double categoryWeight;

	public double getCategoryWeight() {
		return categoryWeight;
	}

	public void setCategoryWeight(double categoryWeight) {
		this.categoryWeight = categoryWeight;
	}

	@JsonBackReference
	@ManyToOne(fetch = FetchType.LAZY)
//	@OnDelete(action = OnDeleteAction.CASCADE)
	
	private Area area;
	


	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}

	public Category(int categoryId, String categoryName, Area area) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.area = area;
	}

	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Category(int categoryId, String categoryName, double categoryWeight, Area area) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.categoryWeight = categoryWeight;
		this.area = area;
	}

}
