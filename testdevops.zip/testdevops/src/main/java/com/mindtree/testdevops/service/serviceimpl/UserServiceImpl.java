package com.mindtree.testdevops.service.serviceimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.hibernate.mapping.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.mindtree.testdevops.entity.Area;
import com.mindtree.testdevops.entity.Category;
import com.mindtree.testdevops.entity.Dashboard;
import com.mindtree.testdevops.entity.Feedback;
import com.mindtree.testdevops.entity.Project;
import com.mindtree.testdevops.entity.Question;
import com.mindtree.testdevops.entity.Role;
import com.mindtree.testdevops.entity.User;
import com.mindtree.testdevops.exception.WrongPasswordException;
import com.mindtree.testdevops.repository.AreaRepository;
import com.mindtree.testdevops.repository.CategoryRepository;
import com.mindtree.testdevops.repository.DashBoardRepository;
import com.mindtree.testdevops.repository.FeedbackRepository;
import com.mindtree.testdevops.repository.ProjectRepository;
import com.mindtree.testdevops.repository.QuestionRepository;
import com.mindtree.testdevops.repository.UserRepository;
import com.mindtree.testdevops.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	ProjectRepository projectRepository;

	@Autowired
	AreaRepository areaRepository;

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	QuestionRepository questionRepository;

	@Autowired
	DashBoardRepository dbRepo;
	
	@Autowired
	FeedbackRepository feedbackRepo;

	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		User savedUser = userRepository.save(user);
		return savedUser;
	}


	@Override
	public List<User> getUsers() {

		List<User> usersWithUserRoles = new ArrayList<User>();
		List<User> users = userRepository.findAll();
		for (User user : users) {
			for (Role roles : user.getRoles()) {
				if (roles.getRoleId() == 3) {
					usersWithUserRoles.add(user);
				}
			}
		}
		Collections.sort(usersWithUserRoles);
		return usersWithUserRoles;
	}

	@Override
	public List<User> getAllUsers() {

		List<User> users = new ArrayList<User>();
		for (User u : userRepository.findAll()) {
			for (Role r : u.getRoles()) {
				if (r.getRoleId() != 1) {
					users.add(u);
				}
			}
		}
		Collections.sort(users);
		return users;
	}

	@Override
	public List<User> removeuser(int id) {
		List<User> newUsers = new ArrayList<User>();
		User user = userRepository.getOne(id);
		for (Project p : userRepository.findById(id).get().getProjects()) {
			for (User u : p.getAccount()) {
				if (u.getUserId() != userRepository.findById(id).get().getUserId()) {
					if (!newUsers.contains(u))
						newUsers.add(u);
					u.setProjects(null);
				}
			}
			p.setAccount(newUsers);
			user.setProjects(null);

			userRepository.save(user);
		}

		for (Feedback f : feedbackRepo.findAll()) {
			if (f.getUser().getUserId() == id) {
				f.setUser(null);
				feedbackRepo.saveAndFlush(f);
			}
		}
		userRepository.deleteById(id);
		List<User> users = new ArrayList<User>();
		for (User u1 : userRepository.findAll()) {
			for (Role r : u1.getRoles()) {
				if (r.getRoleId() != 1) {
					users.add(u1);
				}
			}
		}
		Collections.sort(users);
		return users;
	}

	@Override
	public List<Area> getAreas() {

		return areaRepository.findAll();
	}

	@Override
	public List<Category> getCategories(int areaId) {
		Area area = areaRepository.findById(areaId).get();
		return area.getCategories();
	}

	@Override
	public List<Question> getQuestions(int categoryId) {

		Category cat = categoryRepository.findById(categoryId).get();
		return questionRepository.findByCategory(cat);
	}

	@Override
	public List<Project> getUserProjects(String username) {

		Optional<User> user = userRepository.findByUsername(username);

		return user.get().getProjects();
	}

	@Override
	public User changePassword(String username, String oldPassword, String password1) throws WrongPasswordException {

		User user = userRepository.findByUsername(username).get();

		if (encoder.matches(oldPassword, user.getPassword())) {

			user.setPassword(encoder.encode(password1));
			userRepository.saveAndFlush(user);
		} else {
			throw new WrongPasswordException("Current Password do not match");
		}
		return user;
	}

	@Override
	public List<User> getUsersForDb() {

		List<User> usersWithUserRoles = new ArrayList<User>();
		List<User> users = userRepository.findAll();
		for (User user : users) {
			for (Role roles : user.getRoles()) {
				if (roles.getRoleId() == 3) {
					for (Dashboard d : dbRepo.findAll()) {
						if (d.getProject().getAccount().contains(user)) {
							if (!usersWithUserRoles.contains(user))
								usersWithUserRoles.add(user);
						}
					}

				}
			}
		}

		Collections.sort(usersWithUserRoles);
		System.out.println("users for db " + usersWithUserRoles);
		return usersWithUserRoles;
	}
}