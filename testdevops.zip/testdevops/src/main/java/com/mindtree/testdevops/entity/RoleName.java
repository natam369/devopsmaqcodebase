package com.mindtree.testdevops.entity;

public enum  RoleName {
    ROLE_CLIENT,
    ROLE_VIEWER,
    ROLE_ADMIN,
    ROLE_ARCHI
}
