package com.mindtree.testdevops.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.testdevops.entity.Area;
import com.mindtree.testdevops.entity.AreaScoreCard;
import com.mindtree.testdevops.entity.Category;
import com.mindtree.testdevops.entity.CategoryScoreCard;
import com.mindtree.testdevops.entity.Dashboard;
import com.mindtree.testdevops.entity.Feedback;
import com.mindtree.testdevops.exception.DashboardDoesNotExistException;
import com.mindtree.testdevops.repository.AreaRepository;
import com.mindtree.testdevops.repository.AreaScoreRepository;
import com.mindtree.testdevops.repository.CategoryRepository;
import com.mindtree.testdevops.repository.CategoryScoreRepository;
import com.mindtree.testdevops.repository.DashBoardRepository;
import com.mindtree.testdevops.repository.FeedbackRepository;
import com.mindtree.testdevops.repository.ProjectRepository;
import com.mindtree.testdevops.service.DashboardService;

@Service
public class DashboardServiceimpl implements DashboardService {

	@Autowired
	FeedbackRepository feedbackRepo;

	@Autowired
	CategoryScoreRepository catScoreRepo;

	@Autowired
	AreaScoreRepository areaScoreRepo;

	@Autowired
	CategoryRepository catRepo;

	@Autowired
	AreaRepository areaRepo;

	@Autowired
	ProjectRepository projectRepo;

	@Autowired
	DashBoardRepository dbRepo;

	@Override
	public String calculateCatScore(int pid) {
		List<Feedback> f = feedbackRepo.findAll();
		List<CategoryScoreCard> cs = catScoreRepo.findAll();
		double categoryScore = 0;
		int i = 0;
		for (Category c : catRepo.findAll()) {
			CategoryScoreCard csc = new CategoryScoreCard();
			int j = 0;
			for (Feedback feedback : f) {
				for (CategoryScoreCard check : cs) {
					if (check.getArea().getAreaId() == feedback.getArea().getAreaId()
							&& check.getCategory().getCategoryId() == feedback.getCategory().getCategoryId()
							&& check.getProject().getProjectId() == pid) {
						return " cat already inserted";
					}
				}
				if (feedback.getProject().getProjectId() == pid) {
					if (i == f.size()) {
						break;
					}
					if (c.getCategoryId() == feedback.getCategory().getCategoryId()) {
						categoryScore += feedback.getResponse();
						csc.setArea((feedback.getArea()));
						csc.setProject(feedback.getProject());
						j++;
						i++;
					}
				}

			}
			categoryScore = categoryScore / j;

			csc.setCategory(c);
			csc.setCategoryScore(Math.round(categoryScore * 100.0) / 100.0);
//			csc.setCategoryScore(categoryScore);
			categoryScore = 0;
			csc.setCategoryWeight(c.getCategoryWeight());
			catScoreRepo.save(csc);

		}
		return "success";

	}

	@Override
	public String calculateAreaScore(int pid) {

		// List<Feedback> f = feedbackRepo.findAll();
		List<CategoryScoreCard> csc = catScoreRepo.findAll();
		List<AreaScoreCard> areaScores = areaScoreRepo.findAll();

		double WeightedAreaScore = 0.0;

		for (Area a : areaRepo.findAll()) {
			int j = 0;
			AreaScoreCard areaScore = new AreaScoreCard();
			for (CategoryScoreCard c : csc) {
				for (AreaScoreCard ac : areaScores) {
					if (ac.getArea().getAreaId() == c.getArea().getAreaId() && ac.getProject().getProjectId() == pid) {
						return "area already added";
					}
				}
				if (c.getProject().getProjectId() == pid) {
					if (c.getArea().getAreaId() == a.getAreaId()) {
						areaScore.setProject(c.getProject());
						WeightedAreaScore += (c.getCategoryScore() * c.getCategoryWeight());
						j++;
					}
				}
			}
//			areaScore.setWeightedAreaScore(Math.round(WeightedAreaScore));
			areaScore.setWeightedAreaScore((double) Math.round(WeightedAreaScore * 100.0) / 100.0);
			WeightedAreaScore = 0.0;
			areaScore.setArea(a);
			areaScoreRepo.save(areaScore);
		}
		return "area successfully added";

	}

	@Override
	public String calculateOverAllScore(int pid) {
		List<AreaScoreCard> areaScores = areaScoreRepo.findAll();
		List<Dashboard> dbScores = dbRepo.findAll();
		double overAllScore = 0.0;
		double overAllMaturity = 0;

		int i = 0;
		Dashboard dashboard = new Dashboard();
		for (AreaScoreCard a : areaScores) {
			for (Dashboard db : dbScores) {
				if (db.getProject().getProjectId() == pid) {
					return "score is already calculated";
					// return;
				}
			}
			if (a.getProject().getProjectId() == pid) {
				overAllScore += a.getWeightedAreaScore();
				dashboard.setProject(a.getProject());
				i++;
			}
		}
		overAllScore = overAllScore / i;
		dashboard.setOverAllScore(Math.round(overAllScore * 100.0) / 100.0);
		overAllMaturity = (overAllScore / 5) * 100;
		dashboard.setOverAllMaturity(overAllMaturity);

		dbRepo.save(dashboard);
		// System.out.println(dashboard.getProjid());
		overAllMaturity = 0;
		overAllScore = 0;
		return "overall score added successfully";

	}

	@Override
	public List<CategoryScoreCard> findAll(int projectId) {
		List<CategoryScoreCard> csc = new ArrayList<CategoryScoreCard>();
		int i=0;
		for(Dashboard d: dbRepo.findAll()) {
			if(d.getProject().getProjectId()==projectId) {
			i++;	
		}
		//if(i>0) {
		for (CategoryScoreCard c : catScoreRepo.findAll()) {
			if (c.getProject().getProjectId() == projectId) {
				csc.add(c);
			}
		}
	//	}
//		else {
//			throw new DashboardDoesNotExistException("the dashboard is not yet calculated!");
//		}
//		
		}
		return csc;
	}
//		List<List<CategoryScoreCard>> finallist = new ArrayList<List<CategoryScoreCard>>();
//		List<CategoryScoreCard> a1 = new ArrayList<CategoryScoreCard>();
//		List<CategoryScoreCard> a2 = new ArrayList<CategoryScoreCard>();
//		List<CategoryScoreCard> a3 = new ArrayList<CategoryScoreCard>();
//		List<CategoryScoreCard> a4 = new ArrayList<CategoryScoreCard>();
//		List<CategoryScoreCard> a5 = new ArrayList<CategoryScoreCard>();
//		List<CategoryScoreCard> a6 = new ArrayList<CategoryScoreCard>();
//		for (CategoryScoreCard cat : csc) {
//			if (cat.getArea().getId() == 301)
//				a1.add(cat);
//			if (cat.getArea().getId() == 302)
//				a2.add(cat);
//			if (cat.getArea().getId() == 303)
//				a3.add(cat);
//			if (cat.getArea().getId() == 304)
//				a4.add(cat);
//			if (cat.getArea().getId() == 305)
//				a5.add(cat);
//			if (cat.getArea().getId() == 306)
//				a6.add(cat);
//			
//		}
//		finallist.add(a1);
//		finallist.add(a2);
//		finallist.add(a3);
//		finallist.add(a4);
//		finallist.add(a5);
//		finallist.add(a6);
		
	

	@Override
	public List<AreaScoreCard> findAllAreaScores(int projectId) {
		List<AreaScoreCard> asc = new ArrayList<AreaScoreCard>();
		int i=0;
		for(Dashboard d: dbRepo.findAll()) {
			if(d.getProject().getProjectId()==projectId) {
			i++;	
		}
		}
		if(i>0) {
			for (AreaScoreCard a : areaScoreRepo.findAll()) {
				if (a.getProject().getProjectId() == projectId)
					asc.add(a);
			}
		}
		else {
			//throw new DashboardDoesNotExistException("the dashboard is not yet calculated!");
		}
		return asc;
	}

	@Override
	public List<Double> getCatScores(int projectId){
		
		List<Double> scores = new ArrayList<Double>();
		int i=0;
		for(Dashboard d: dbRepo.findAll()) {
			if(d.getProject().getProjectId()==projectId) {
			i++;	
		}
		}
		//if(i>0) {
		for (CategoryScoreCard c : catScoreRepo.findAll()) {
			if (c.getProject().getProjectId() == projectId) {
				scores.add(c.getCategoryScore());
			}
		}
		return scores;
//		else {
//			//throw new DashboardDoesNotExistException("the dashboard is not yet calculated!");
//		}
		
	}

	@Override
	public List<List<CategoryScoreCard>> findAllcat(int projectId) {
		
		List<CategoryScoreCard> csc = new ArrayList<CategoryScoreCard>();
		
		for (CategoryScoreCard c : catScoreRepo.findAll()) {
			if (c.getProject().getProjectId() == projectId) {
				csc.add(c);
			}
		}
		List<List<CategoryScoreCard>> finallist = new ArrayList<List<CategoryScoreCard>>();
		List<CategoryScoreCard> a1 = new ArrayList<CategoryScoreCard>();
		List<CategoryScoreCard> a2 = new ArrayList<CategoryScoreCard>();
		List<CategoryScoreCard> a3 = new ArrayList<CategoryScoreCard>();
		List<CategoryScoreCard> a4 = new ArrayList<CategoryScoreCard>();
		List<CategoryScoreCard> a5 = new ArrayList<CategoryScoreCard>();
		List<CategoryScoreCard> a6 = new ArrayList<CategoryScoreCard>();
		for (CategoryScoreCard cat : csc) {
			if (cat.getArea().getAreaId() == 301)
				a1.add(cat);
			if (cat.getArea().getAreaId() == 302)
				a2.add(cat);
			if (cat.getArea().getAreaId() == 303)
				a3.add(cat);
			if (cat.getArea().getAreaId() == 304)
				a4.add(cat);
			if (cat.getArea().getAreaId() == 305)
				a5.add(cat);
			if (cat.getArea().getAreaId()== 306)
				a6.add(cat);

		}
		finallist.add(a1);
		finallist.add(a2);
		finallist.add(a3);
		finallist.add(a4);
		finallist.add(a5);
		finallist.add(a6);
		return finallist;
	}
	
	 @Override
	    public Dashboard getDashboardScore(int projectId){
	        Dashboard db = new Dashboard();
	        int i=0;
	        for (Dashboard dashboard : dbRepo.findAll()) {
	            if (dashboard.getProject().getProjectId() == projectId) {
	                db = dashboard;
	                i++;
	            }
	        }
//	        if(i>0) {
//	        	 return db;
//	        }
//	        else {
//	        	//throw new DashboardDoesNotExistException("dashboard is not yet calculated!");
//	        }
	     return db;  
	    }
}
