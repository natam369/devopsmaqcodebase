package com.mindtree.testdevops.service;

import java.util.List;

import com.mindtree.testdevops.entity.AreaScoreCard;
import com.mindtree.testdevops.entity.CategoryScoreCard;
import com.mindtree.testdevops.entity.Dashboard;
import com.mindtree.testdevops.exception.DashboardDoesNotExistException;

public interface DashboardService {

	String calculateCatScore(int pid);

	String calculateAreaScore(int pid);

	List<CategoryScoreCard> findAll(int projectId);

	List<List<CategoryScoreCard>> findAllcat(int projectId);

	List<Double> getCatScores(int projectId);

	List<AreaScoreCard> findAllAreaScores(int projectId);

	String calculateOverAllScore(int pid);

	Dashboard getDashboardScore(int projectId);

}
