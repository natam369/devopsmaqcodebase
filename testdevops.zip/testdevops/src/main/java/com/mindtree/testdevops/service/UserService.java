package com.mindtree.testdevops.service;

import java.util.List;

import com.mindtree.testdevops.entity.Area;
import com.mindtree.testdevops.entity.Category;
import com.mindtree.testdevops.entity.Project;
import com.mindtree.testdevops.entity.Question;
import com.mindtree.testdevops.entity.User;
import com.mindtree.testdevops.exception.WrongPasswordException;

public interface UserService {

	User saveUser(User user);

	List<User> getUsers();

	List<User> getAllUsers();

	List<User> removeuser(int id);

	List<Area> getAreas();

	List<Category> getCategories(int areaId);

	List<Question> getQuestions(int categoryId);

	List<Project> getUserProjects(String username);

	List<User> getUsersForDb();
	
	User changePassword(String username, String oldPassword, String password1) throws WrongPasswordException;

}
