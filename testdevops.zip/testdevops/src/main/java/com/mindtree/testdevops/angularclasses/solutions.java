package com.mindtree.testdevops.angularclasses;

public class solutions {
	
	private String question;
	private int questionId;
	private int option;
	private String remarks;
	
	
	public String getQuestion() {
		return question;
	}


	public void setQuestion(String question) {
		this.question = question;
	}


	public int getQuestionId() {
		return questionId;
	}


	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}


	public int getOption() {
		return option;
	}


	public void setOption(int option) {
		this.option = option;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public solutions(String question, int questionId, int option, String remarks) {
		super();
		this.question = question;
		this.questionId = questionId;
		this.option = option;
		this.remarks = remarks;
	}


	public solutions() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	


}
