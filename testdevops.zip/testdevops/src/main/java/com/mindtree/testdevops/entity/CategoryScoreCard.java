package com.mindtree.testdevops.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class CategoryScoreCard {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int csid;
	@OneToOne
	private Category category;
	@OneToOne
	private Project project;
	// Feedback feedback[];
	@Column( columnDefinition = "Decimal(10,2)")
	double categoryScore;
	double categoryWeight;
	@OneToOne
	private Area area;

	public int getCsid() {
		return csid;
	}

	public void setCsid(int csid) {
		this.csid = csid;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public double getCategoryScore() {
		return categoryScore;
	}

	public void setCategoryScore(double categoryScore) {
		this.categoryScore = categoryScore;
	}

	public double getCategoryWeight() {
		return categoryWeight;
	}

	public void setCategoryWeight(double categoryWeight) {
		this.categoryWeight = categoryWeight;
	}

	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}

}
