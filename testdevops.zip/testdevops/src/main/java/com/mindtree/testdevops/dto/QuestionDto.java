package com.mindtree.testdevops.dto;

import javax.persistence.OneToOne;

import com.mindtree.testdevops.entity.Category;

public class QuestionDto {
	private int questionId;
	private String question;

	
	private Category category;


	public int getQuestionId() {
		return questionId;
	}


	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}


	public String getQuestion() {
		return question;
	}


	public void setQuestion(String question) {
		this.question = question;
	}


	public Category getCategory() {
		return category;
	}


	public void setCategory(Category category) {
		this.category = category;
	}
	
}
