package com.mindtree.testdevops.service.serviceimpl;

import org.springframework.stereotype.Service;

import com.mindtree.testdevops.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService{

}
