package com.mindtree.testdevops.service.serviceimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.testdevops.entity.AreaScoreCard;
import com.mindtree.testdevops.entity.CategoryScoreCard;
import com.mindtree.testdevops.entity.Dashboard;
import com.mindtree.testdevops.entity.Feedback;
import com.mindtree.testdevops.entity.Project;
import com.mindtree.testdevops.entity.Role;
import com.mindtree.testdevops.entity.User;
import com.mindtree.testdevops.repository.AreaScoreRepository;
import com.mindtree.testdevops.repository.CategoryScoreRepository;
import com.mindtree.testdevops.repository.DashBoardRepository;
import com.mindtree.testdevops.repository.FeedbackRepository;
import com.mindtree.testdevops.repository.ProjectRepository;
import com.mindtree.testdevops.repository.UserRepository;
import com.mindtree.testdevops.service.ProjectService;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	ProjectRepository projectRepo;

	@Autowired
	UserRepository userRepo;

	@Autowired
	DashBoardRepository dbRepo;

	@Autowired
	CategoryScoreRepository catScoreRepo;
	
	@Autowired
	AreaScoreRepository areaScoreRepo;
	
	@Autowired
	FeedbackRepository fRepo;

	@Override
	public Project saveProject(int userid, Project project, int archiId) {

		User account = userRepo.findById(userid).get();
		List<User> users = new ArrayList<User>();
		users.add(account);
		project.setAccount(users);

		List<Project> projects = projectRepo.findAll();
		for (Project p : projects) {
			if (p.getProjectName().equalsIgnoreCase(project.getProjectName())) {
				for (User u : p.getAccount()) {
					for (Role role : u.getRoles()) {
						if (role.getRoleId() == 3) {
							System.out.println("account is already assigned to this project");
							System.out.println(assignArchitect(p.getProjectId(), archiId));
							return p;
						}

					}

				}
				System.out.println("project role is different");

				System.out.println(assignArchitect(p.getProjectId(), archiId));
				return p;
				// projectRepo.save(project);
			}

		}
		System.out.println("project doesnot exist so add");
		Project p = projectRepo.save(project);
		assignArchitect(project.getProjectId(), archiId);
		return p;

	}

	@Override
	public List<User> getArchitects() {
		// List<Project> projects = projectRepo.findAll();
		List<User> users = userRepo.findAll();
		List<User> archis = new ArrayList<User>();
		for (User user : users) {
			for (Role roles : user.getRoles()) {
				if (roles.getRoleId() == 4) {
					archis.add(user);
				}
			}
		}
		Collections.sort(archis);
		return archis;
	}

	@Override
	public List<Project> getProjects() {

		List<Project> projects = projectRepo.findAll();
		Collections.sort(projects);
		return projects;
	}

	@Override
	public List<Project> deleteProject(int projectId) {

		List<Project> newProjects = new ArrayList<Project>();
		Project project = projectRepo.findById(projectId).get();
		for (User u : projectRepo.findById(projectId).get().getAccount()) {
			for (Project p : u.getProjects()) {
				if (p.getProjectId() != projectRepo.findById(projectId).get().getProjectId()) {
					if (!newProjects.contains(p)) {
						newProjects.add(p);

					}
				}
			}
			u.setProjects(newProjects);
			project.setAccount(null);
			projectRepo.save(project);
		}

		for (Feedback f : fRepo.findAll()) {
			if (f.getProject().getProjectId() == projectId) {
				fRepo.delete(f);
			}
		}
		for (CategoryScoreCard c : catScoreRepo.findAll()) {
			if (c.getProject().getProjectId() == projectId) {
				catScoreRepo.delete(c);
			}
		}
		for (AreaScoreCard a : areaScoreRepo.findAll()) {
			if (a.getProject().getProjectId() == projectId) {
				areaScoreRepo.delete(a);
			}
		}
		for (Dashboard d : dbRepo.findAll()) {
			if (d.getProject().getProjectId() == projectId) {
				dbRepo.delete(d);
			}
		}
		projectRepo.deleteById(projectId);
		List<Project> projects = projectRepo.findAll();
		Collections.sort(projects);
		return projects;
	}

	@Override
	public String assignArchitect(int projectId, int userId) {
		Project project = projectRepo.findById(projectId).get();
		User user = userRepo.findById(userId).get();
		int count = 0;
		List<User> users = project.getAccount();
		users.add(user);
		project.setAccount(users);
		for (User u : project.getAccount()) {
			if (u.getUsername().equalsIgnoreCase(user.getUsername())) {
				count++;
			}
		}
		if (count > 1) {
			return "architect is already assigned";
		} else {
			projectRepo.saveAndFlush(project);
			return "assigned";
		}
	}

	@Override
	public List<Project> getUserProjectsForDb(String username) {
		Optional<User> user = userRepo.findByUsername(username);
		List<Project> projectForDb = new ArrayList<Project>();
		for (Project p : user.get().getProjects()) {
			for (Dashboard d : dbRepo.findAll()) {
				if (d.getProject().getProjectId() == p.getProjectId()) {
					projectForDb.add(p);
				}
			}
		}
		return projectForDb;

	}

}
