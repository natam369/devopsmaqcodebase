package com.mindtree.testdevops.dto;

import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mindtree.testdevops.entity.Area;
import com.mindtree.testdevops.entity.Category;
import com.mindtree.testdevops.entity.Project;
import com.mindtree.testdevops.entity.Question;
import com.mindtree.testdevops.entity.User;

public class ExistingFeedback {
	
	private User user;
	
	private Project project;
    @JsonIgnoreProperties("categories")
	private Area area;
    @JsonIgnoreProperties("area")
	private Category category;

	private Question question;
	private int response;
	private String remarks;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public int getResponse() {
		return response;
	}

	public void setResponse(int response) {
		this.response = response;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
