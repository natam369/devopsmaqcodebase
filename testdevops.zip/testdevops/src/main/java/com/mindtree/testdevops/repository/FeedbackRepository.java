package com.mindtree.testdevops.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.testdevops.entity.Feedback;

public interface FeedbackRepository extends JpaRepository<Feedback, Integer> {

}
