package com.mindtree.testdevops.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.testdevops.angularclasses.FeedBackFormValue;
import com.mindtree.testdevops.entity.Feedback;
import com.mindtree.testdevops.entity.Question;
import com.mindtree.testdevops.entity.User;
import com.mindtree.testdevops.repository.AreaRepository;
import com.mindtree.testdevops.repository.CategoryRepository;
import com.mindtree.testdevops.repository.FeedbackRepository;
import com.mindtree.testdevops.repository.ProjectRepository;
import com.mindtree.testdevops.repository.QuestionRepository;
import com.mindtree.testdevops.repository.UserRepository;
import com.mindtree.testdevops.service.FeedbackService;
import com.mindtree.testdevops.service.QuestionService;

@Service
public class FeedbackServiceImpl implements FeedbackService {

	@Autowired
	UserRepository userRepo;

	@Autowired
	ProjectRepository projectRepo;

	@Autowired
	AreaRepository areaRepo;

	@Autowired
	CategoryRepository categoryRepo;

	@Autowired
	QuestionRepository questionRepo;

	@Autowired
	FeedbackRepository feedbackRepo;

	@Autowired
	QuestionService qservice;

//	@Override
//	public void savefeedback(Question[] question, int[] response, String[] remarks) {
//		int j = 0;
//
//		while (j != (question.length)) {
//			Feedback f = new Feedback();
//			f.setCategory(question[j].getCategory());
//			f.setArea(question[j].getCategory().getArea());
//			f.setQuestion(question[j]);
//			f.setResponse(response[j]);
//			f.setRemarks(remarks[j]);
//			feedbackRepo.save(f);
//			j++;
//
//		}
//
//	}
	@Override
	public String saveFeedback(FeedBackFormValue feedback, String username, int projectId) {
		// feedback.getSolution().get(i).getQuestionId()
//		int j = 0;
//		while (j != (feedback.getSolution().size())) {
//			Feedback f = new Feedback();
//			Question q = questionRepo.getOne(feedback.getSolution().get(j).getQuestionId());
//			f.setQuestion(q);
//			f.setCategory(q.getCategory());
//			f.setArea(q.getCategory().getArea());
//			f.setResponse(feedback.getSolution().get(j).getOption());
//			f.setRemarks(feedback.getSolution().get(j).getRemarks());
//			feedbackRepo.save(f);
//			j++;
//
//		}
		int j = 0;
		String s = null;
		List<Feedback> feedbackList = feedbackRepo.findAll();
		while (j != (feedback.getSolution().size())) {
			Feedback f = new Feedback();
			Question q = questionRepo.getOne(feedback.getSolution().get(j).getQuestionId());
			f.setQuestion(q);
			f.setCategory(q.getCategory());
			f.setArea(q.getCategory().getArea());
			f.setResponse(feedback.getSolution().get(j).getOption());
			f.setRemarks(feedback.getSolution().get(j).getRemarks());
			f.setProject(projectRepo.getOne(projectId));
			// f.setUser(userRepo.findByUsername(username));
			f.setUser(userRepo.findByUsername(username).get());
			int check = 0;
			for (Feedback feed : feedbackList) {
				if (f.getProject().getProjectId() == feed.getProject().getProjectId()
						&& f.getArea().getAreaId() == feed.getArea().getAreaId()
						&& f.getCategory().getCategoryId() == feed.getCategory().getCategoryId()
						&& f.getQuestion().getQuestionId() == feed.getQuestion().getQuestionId()
						&& f.getUser().getUserId() == feed.getUser().getUserId()) {
					check = 1;
					feed.setResponse(f.getResponse());
					feed.setRemarks(f.getRemarks());
					if(feed.getResponse()!=6) {
					feedbackRepo.saveAndFlush(feed);
					}
					

					s += f.getQuestion().getQuestionId() + "updated.......";
					break;
				}
			}
			if (check == 0) {
				if(f.getResponse()!=6)
				feedbackRepo.save(f);
			}
			j++;
		}
		return s;
	}

	@Override
	public List<Integer> getExistingAreaFeedback(String username, int projectId) {
		List<Feedback> feedback = feedbackRepo.findAll();

		List<Integer> catId = new ArrayList<Integer>();

		User user = userRepo.findByUsername(username).get();

		for (Feedback f : feedback) {
			if (f.getUser().getUserId() == user.getUserId() && f.getProject().getProjectId() == projectId) {

				if (!catId.contains(f.getCategory().getCategoryId())) {
					catId.add(f.getCategory().getCategoryId());
				}
			}
		}

		System.out.println("cat size" + catId.size());
		return catId;
	}

	@Override
	public List<Question> getExistingQuestionFeedback(String username, int projectId) {
		List<Feedback> feedback = feedbackRepo.findAll();
		List<Question> qstn = new ArrayList<Question>();
		User user = userRepo.findByUsername(username).get();
		for (Feedback f : feedback) {
			if (f.getUser().getUserId() == user.getUserId() && f.getProject().getProjectId() == projectId) {

				if (!qstn.contains(f.getQuestion())) {
					qstn.add(f.getQuestion());
				}
			}
		}
		System.out.println("qstns size" + qstn.size());
		return qstn;
	}

	@Override
	public List<Feedback> getExistingFeedback(String username, int projectId) {

		List<Feedback> feedback = feedbackRepo.findAll();
		List<Feedback> savedFeedback = new ArrayList<Feedback>();
		User user = userRepo.findByUsername(username).get();

		for (Feedback f : feedback) {
			if (f.getUser().getUserId() == user.getUserId() && f.getProject().getProjectId() == projectId) {
				savedFeedback.add(f);
			}
		}
		System.out.println("sending existing feedback");
		return savedFeedback;
	}

}
