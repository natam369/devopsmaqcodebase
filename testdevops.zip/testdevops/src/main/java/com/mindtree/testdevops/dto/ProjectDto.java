package com.mindtree.testdevops.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mindtree.testdevops.entity.User;

public class ProjectDto {
	private int projectId;
	private String projectName;
	private List<User> account;
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public List<User> getAccount() {
		return account;
	}
	public void setAccount(List<User> account) {
		this.account = account;
	}
	

}
