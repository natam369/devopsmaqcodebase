package com.mindtree.testdevops.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mindtree.testdevops.exception.DashboardDoesNotExistException;
import com.mindtree.testdevops.exception.ProjectAlreadyExistsException;
import com.mindtree.testdevops.message.response.ExceptionResponse;

@ControllerAdvice
public class ControllerExceptionHandler {
	@ExceptionHandler(ProjectAlreadyExistsException.class)
	@ResponseBody
	public ResponseEntity<Object> handleProjectAlreadyExistsException(ProjectAlreadyExistsException exception) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ExceptionResponse(exception.getMessage()));
	}
	@ExceptionHandler(DashboardDoesNotExistException.class)
	@ResponseBody
	public ResponseEntity<Object> handleDashboardIsNotCalculated(DashboardDoesNotExistException exception) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ExceptionResponse(exception.getMessage()));
	}
	
	@ExceptionHandler(com.mindtree.testdevops.exception.WrongPasswordException.class)
	@ResponseBody
	public ResponseEntity<Object> WrongPasswordException(com.mindtree.testdevops.exception.WrongPasswordException exception) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ExceptionResponse(exception.getMessage()));
	}
}
