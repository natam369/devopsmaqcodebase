package com.mindtree.testdevops.message.response;

public class ExceptionResponse {
	private String message;

	public ExceptionResponse(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setErrorMessage(String message) {
		this.message = message;
	}

}
