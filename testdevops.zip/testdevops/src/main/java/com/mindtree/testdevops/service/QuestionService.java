package com.mindtree.testdevops.service;

import java.util.List;

import com.mindtree.testdevops.dto.ExistingFeedback;
import com.mindtree.testdevops.entity.Question;

public interface QuestionService {

	Question getQuestion(int questionId);

	List<Question> getAllQuestions();

	List<ExistingFeedback> getAllForPatchValues(String username, int projectId);
}
