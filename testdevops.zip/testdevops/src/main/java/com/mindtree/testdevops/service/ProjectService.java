package com.mindtree.testdevops.service;

import java.util.List;

import com.mindtree.testdevops.entity.Project;
import com.mindtree.testdevops.entity.User;

public interface ProjectService {

	//Project saveProjects(int userid, Project project);

	List<Project> getProjects();

	List<Project> deleteProject(int projectId);

	//Project saveProjects(String projectName, String username);
	
	List<User> getArchitects();

	String assignArchitect(int projectId, int userId);
	
	Project saveProject(int userid, Project project, int archiId);

	List<Project> getUserProjectsForDb(String username);
}
