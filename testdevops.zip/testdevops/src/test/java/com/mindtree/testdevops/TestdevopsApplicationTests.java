package com.mindtree.testdevops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestdevopsApplicationTests {

	@Test
	void contextLoads() {
	}

}
